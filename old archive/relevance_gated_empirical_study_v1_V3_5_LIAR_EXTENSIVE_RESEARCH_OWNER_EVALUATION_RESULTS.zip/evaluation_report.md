# V3.2 evaluation report

This report is owner-side only because it uses private targets.

## Metrics

| Dataset | Status | n | Spearman | Pearson | MAE | Model mean | Target mean |
|---|---:|---:|---:|---:|---:|---:|---:|
| HumAID | not evaluated - missing scorer output | 0 | — | — | — | — | — |
| CredEvent_TurkRatings | not evaluated - missing scorer output | 0 | — | — | — | — | — |
| LIAR_PolitiFact | evaluated | 200 | 0.630 | 0.560 | 0.263 | 0.436 | 0.390 |

## Diagnostics

### HumAID
Validation issues: missing file

### CredEvent_TurkRatings
Validation issues: missing file

### LIAR_PolitiFact
Validation issues: none detected.

| Variable | Mean | p10 | p90 |
|---|---:|---:|---:|
| W | 0.500 | 0.500 | 0.500 |
| X | 0.500 | 0.500 | 0.500 |
| U | 0.500 | 0.500 | 0.500 |
| AC | 0.500 | 0.500 | 0.500 |
| Rel | 0.848 | 0.860 | 0.860 |
| AD | 0.500 | 0.500 | 0.500 |
| Y | 0.500 | 0.500 | 0.500 |