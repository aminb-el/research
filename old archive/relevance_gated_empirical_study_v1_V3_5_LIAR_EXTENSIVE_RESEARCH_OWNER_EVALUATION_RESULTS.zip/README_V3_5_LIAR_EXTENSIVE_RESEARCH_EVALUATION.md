# V3.5 LIAR Extensive-Research Evaluation (Owner Side)

This package evaluates the uploaded V3.5 external LIAR research-scoring output. It is owner-side only because target labels/scores are joined in diagnostics.

## Structural audit

- Required files present: 5 / 5.
- Atomic score rows: 200 / 200.
- Row research logs: 200 / 200.
- Source usage log rows: 780.
- Unresolved rows: 4.
- possible_leakage_flag sum: 0.
- uncertainty_flag sum: 143.
- Direct banned source hits in URL/title/publisher/query audit: 0.
- Rows where forbidden search results were seen but not used: 1.

## LIAR metrics

| Run | Spearman | Pearson | MAE | Model mean | Target mean |
|---|---:|---:|---:|---:|---:|
| V3.4 researched | 0.525 | 0.481 | 0.277 | 0.477 | 0.390 |
| V3.5 extensive researched | 0.630 | 0.560 | 0.263 | 0.436 | 0.390 |

## Interpretation

V3.5 improves rank correlation and linear correlation over V3.4. The main improvement is stronger exact-claim updating in K_mean, L, and M, with less excessive regression toward 0.5.

The result is still not a clean final validation because MAE remains high and four rows were unresolved. The source log says the scorer performed extensive research, but the session log also admits a deviation: not every source was fully opened in a live browser transcript during the same run. Treat this as a stronger LIAR diagnostic, not a perfectly audited human-grade fact-checking study.

