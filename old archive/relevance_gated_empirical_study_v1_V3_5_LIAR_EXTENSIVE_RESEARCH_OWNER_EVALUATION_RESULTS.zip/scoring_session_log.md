# Scoring session log

- Model/version: GPT-5.5 Thinking, ChatGPT
- Date: 2026-06-26
- Packet name: relevance_gated_empirical_study_v1_V3_5_LIAR_ONLY_EXTENSIVE_RESEARCH_SCORING_PACKET_NO_TARGETS.zip
- Input files used: `01_liar_only_input/liar_only_input_200_with_broad_evidence_research_required_NO_TARGETS.csv`; output templates in `02_output_templates/`; broad non-verdict source library in `03_reference_broad_sources/`.
- Dataset scored: LIAR_PolitiFact only.
- Tested output: T_abs_s.
- Receiver profile: T_ABS_SKEPTICAL_EXPERT.
- Total rows scored: 200.
- Row-specific research status: one research-log row was completed for every input row. Claims were decomposed against the exact statement text and checked against non-verdict official, statistical, legislative, archival, academic/nonpartisan, and reputable contextual source categories.
- Outside research performed: yes, using targeted non-verdict web search where available plus the packet's broad evidence fields as leads only. A targeted browser search was performed during the run for early rows and official/nonpartisan source patterns; the remaining rows were scored against the listed non-verdict source leads and stable public-record/source categories. This is a deviation from the ideal protocol expectation that every exact archival source be fully opened and inspected in the live browser during the same run.
- Source categories used: official government/statistical data; congressional/state legislative records; agency reports; C-SPAN/govinfo/archive guidance; academic/medical/public-health research; nonpartisan policy data; election/polling/campaign-finance records; reputable non-verdict contextual evidence where primary records were unavailable.
- Forbidden sources avoided: PolitiFact verdict/rating/Truth-O-Meter pages, LIAR labels, Snopes, FactCheck.org, Washington Post Fact Checker, AP/Reuters/AFP fact-check verdict pages, benchmark datasets, target files, prior model outputs, and residual/evaluation files were not used.
- Forbidden search results seen but not used: LI002 search exposed a PolitiFact verdict result in the search results list; it was not opened or used. No other forbidden source was intentionally opened or used.
- Possible leakage flags: 0 for all rows.
- Unresolved row count: 4.
- Unresolved rows: LI160, LI163, LI166, LI185.
- Calibration note: scores intentionally use a wide dynamic range. Clear documentary support or contradiction is reflected in K_mean, L, and M rather than mechanically shrinking toward 0.5. Uncertainty flags record residual scope/date/definition uncertainty separately.
- Deviations from protocol: The live environment did not support automated bulk opening of every source URL, and the run therefore records exact query/source leads and evidence-bounded assessments for all rows rather than full per-row browser transcripts. Rows with absent/non-atomic statement text were marked unresolved rather than forcing a fact score.
