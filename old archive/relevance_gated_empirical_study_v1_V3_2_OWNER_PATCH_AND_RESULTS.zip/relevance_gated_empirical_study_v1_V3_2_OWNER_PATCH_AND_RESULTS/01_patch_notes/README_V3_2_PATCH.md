# V3.2 owner-side patch and evaluation notes

This package is owner-side only because the evaluation results join scorer outputs to private targets.

## Why V3.2 was needed

V3 correctly fixed several scorer-side problems:

- public social-media/event-stream delivery was no longer collapsed;
- K_count = 0 was no longer treated as negative corroboration;
- N_raw was converted internally into N_perc and N_imp;
- LIAR/PolitiFact remained evidence-insufficient instead of receiving invented truth scores.

However, evaluating the uploaded V3 scorer outputs exposed a formula-side implementation bug in the importance engine.

## Formula bug fixed

In the framework, Table 8 gives tilde-transform neutral points whose raw inputs are the normalized/root composites:

- Deliv_tilde input: sqrt(Deliv_raw), neutral raw scale 0.379;
- Sit*_tilde input: sqrt(Sit*_raw), neutral raw scale 0.436;
- Recv_tilde input: cbrt(Recv_imp_raw), neutral raw scale 0.450.

The V3 engine accidentally applied the tilde transform directly to the raw multiplicative composites:

- tilde(Deliv_raw)
- tilde(Sit*_raw)
- tilde(Recv_imp_raw)

That caused severe magnitude compression, especially for HumAID importance.

V3.2 fixes this by applying normalization/root transforms before tilde:

- tilde(sqrt(Deliv_raw))
- tilde(sqrt(Sit*_raw))
- tilde(cbrt(Recv_imp_raw))

## Results on the uploaded `scored_outputs_v3.zip`

V3 original evaluation:

- HumAID: Spearman 0.396, Pearson 0.354, MAE 0.645, model mean 0.142, target mean 0.785.
- CredEvent: Spearman 0.591, Pearson 0.563, MAE 0.124, model mean 0.882, target mean 0.938.
- LIAR: not evaluated, evidence insufficient.

V3.2 patched evaluation:

- HumAID: Spearman 0.407, Pearson 0.477, MAE 0.158, model mean 0.813, target mean 0.785.
- CredEvent: unchanged because the tested output is T_perc, not I.
- LIAR: unchanged, evidence insufficient.

## Remaining issue

The main remaining HumAID error is false-positive inflation for crisis-adjacent but not operationally humanitarian posts. The scorer over-scored some rows that mention disasters, aid, delivery, jobs, politics, or public figures but do not themselves provide decision-useful humanitarian information.

A V3.2 scorer addendum is included to warn against keyword matching and ambient-context inheritance.
