# V3.2 evaluation report

This report is owner-side only because it uses private targets.

## Metrics

| Dataset | Status | n | Spearman | Pearson | MAE | Model mean | Target mean |
|---|---:|---:|---:|---:|---:|---:|---:|
| HumAID | evaluated | 200 | 0.407 | 0.477 | 0.158 | 0.813 | 0.785 |
| CredEvent_TurkRatings | evaluated | 200 | 0.591 | 0.563 | 0.124 | 0.882 | 0.938 |
| LIAR_PolitiFact | not evaluated - evidence insufficient | 200 | — | — | — | — | — |

## Diagnostics

### HumAID
Validation issues: none detected.

| Variable | Mean | p10 | p90 |
|---|---:|---:|---:|
| W | 0.744 | 0.700 | 0.780 |
| X | 0.839 | 0.840 | 0.870 |
| U | 0.522 | 0.520 | 0.520 |
| AC | 0.727 | 0.350 | 0.900 |
| Rel | 0.774 | 0.420 | 0.920 |
| AD | 0.817 | 0.500 | 0.930 |
| Y | 0.809 | 0.650 | 0.860 |

### CredEvent_TurkRatings
Validation issues: none detected.

| Variable | Mean | p10 | p90 |
|---|---:|---:|---:|
| W | 0.816 | 0.800 | 0.830 |
| X | 0.896 | 0.900 | 0.900 |
| U | 0.582 | 0.520 | 0.620 |
| AC | 0.755 | 0.690 | 0.830 |
| Rel | 0.833 | 0.854 | 0.860 |
| AD | 0.663 | 0.460 | 0.800 |
| Y | 0.724 | 0.620 | 0.820 |

### LIAR_PolitiFact
Validation issues: none detected.

| Variable | Mean | p10 | p90 |
|---|---:|---:|---:|
| W | 0.500 | 0.500 | 0.500 |
| X | 0.500 | 0.500 | 0.500 |
| U | 0.500 | 0.500 | 0.500 |
| AC | 0.500 | 0.500 | 0.500 |
| Rel | 0.500 | 0.500 | 0.500 |
| AD | 0.500 | 0.500 | 0.500 |
| Y | 0.500 | 0.500 | 0.500 |