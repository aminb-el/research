# Optional V3.2 scorer addendum — HumAID anti-keyword-trap guidance

Use this only in future scorer reruns. It contains no private targets or labels.

## Core rule

For HumAID importance, do not score a post as high merely because it is posted during a disaster event or contains disaster-adjacent words such as aid, delivery, front lines, damage, Trump, blame, fire, flood, hurricane, refugees, job, donate, or emergency.

The statement itself must provide operational, informational, evidential, need-related, warning-related, infrastructure-related, safety-related, rescue-related, missing-person-related, injury/death-related, evacuation-related, or coordination-related content useful to a crisis-monitoring receiver.

## Low Rel / low AC cases

Assign low-to-moderate Rel and AC when the message is primarily:

- political blame or commentary;
- a job advertisement or generic recruitment post;
- a personal status unrelated to disaster response;
- a media teaser mentioning multiple unrelated topics;
- sarcasm, outrage, gratitude, jokes, or opinion without actionable crisis content;
- discussion of a public figure, institution, or controversy without a direct update on humanitarian conditions.

These posts may have high ambient Y because the event context is serious, but Rel should prevent the ambient disaster context from inflating importance when the statement itself is not humanitarian-response information.

## Examples without target labels

Example A: “I’m hungry @ South Philadelphia” during a hurricane event.
- Ambient context may be a hurricane, but the statement does not report disaster need, danger, damage, evacuation, shelter, rescue, or infrastructure status.
- Rel low, AC low-to-moderate at most, AD not inherited from the hurricane.

Example B: “Fresh food, fun work! Join our team today! Delivery Driver in Raleigh.” during a hurricane event.
- Contains words like fresh food, delivery, Raleigh, and work, but it is a job ad, not a crisis logistics update.
- Rel low unless the post explicitly coordinates disaster relief.

Example C: “University fires professor who blamed Hurricane Harvey on Trump vote.”
- Mentions Hurricane Harvey but is about political/media controversy, not humanitarian conditions.
- Rel should be low-to-moderate, not high.

Example D: “Road washed out on Highway 12; emergency vehicles cannot pass.”
- Direct operational/infrastructure consequence.
- Rel high, AC high for crisis-monitor receiver, AD high.

Example E: “Need insulin and bottled water at shelter near X; elderly residents present.”
- Direct urgent need.
- Rel high, AC high, AD high.
