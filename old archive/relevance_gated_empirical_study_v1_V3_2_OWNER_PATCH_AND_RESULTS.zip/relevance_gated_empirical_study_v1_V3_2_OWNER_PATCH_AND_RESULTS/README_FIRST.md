# V3.2 owner patch package

This package contains the V3.2 owner-side formula/evaluation patch and evaluation results for the uploaded `scored_outputs_v3.zip`.

Do not send this package to an external scorer because it contains evaluation results joined to private targets.

Contents:

- `01_patch_notes/README_V3_2_PATCH.md` — diagnosis and patch rationale.
- `02_formula_and_evaluation_v3_2/` — patched formula engine and evaluator.
- `03_evaluation_results_on_scored_outputs_v3/` — V3.2 metrics, audits, HumAID group means, and original V3 comparison.
- `04_scorer_addendum_optional/` — safe addendum for future scorer reruns, with no target labels.

Main finding:

- CredEvent is now strong enough for an empirical table candidate.
- HumAID becomes numerically usable only after the V3.2 formula patch, but still has a remaining false-positive issue on disaster-adjacent/non-operational posts.
- LIAR/PolitiFact remains excluded until real evidence packets are filled.
