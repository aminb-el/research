# Methodology and interpretation rules

## Primary estimand

The study keeps every exported gap, including gaps whose repeated occurrence is structurally forbidden
modulo 3. The primary question is conditional and empirical:

> Given the exact multiset of gaps in each window, how many adjacent equal-gap repeats occur in the real
> ordering compared with an unrestricted random ordering?

The primary quantities are the real count R, unrestricted-shuffle expectation E, missing count E-R,
count ratio R/E, proportional suppression 1-R/E, and all three counts normalized per 100,000 adjacent
pairs.

## Uncertainty

The arithmetic counts themselves are fixed. Bootstrap intervals quantify spatial variation among the
25 sampled windows at each scale, not uncertainty about the computed integers. Two global designs are
reported:

1. fixed-grid bootstrap: all 46 scales remain fixed and windows are resampled within each scale;
2. hierarchical bootstrap: scales are resampled and then windows are resampled within scales, giving a
   broader scale-generalization interval.

## Count models

The primary model is a Poisson log-link count model with the unrestricted-shuffle expectation as an
offset:

    log E[R_w] = log(E_w) + alpha + beta / power.

This directly models the multiplicative real-to-shuffle count ratio. Standard errors are two-way
clustered by scale and repeated window position. GEE fits with independence, exchangeable, and AR(1)
working correlations are sensitivity analyses. A negative-binomial model checks extra-Poisson
variation.

## Scale synthesis

A random-effects meta-analysis treats the 46 scale-level log ratios as scale-balanced effects, using
within-scale bootstrap standard errors. A REML meta-regression on inverse power measures how much
heterogeneity remains after the scale trend is modeled.

## Composition decomposition

The Kitagawa decomposition separates the change in the total real/shuffle ratio between powers 10 and
100 into:

- composition: changes in the expected-count weights of gap groups;
- within-group: changes in the real/shuffle ratio inside each group.

When a group has zero expected mass at one endpoint, its ratio is undefined; the other endpoint ratio is
used so its appearance or disappearance is assigned to composition.

## Modulo 3

Modulo 3 is an explanatory layer, not a correction to the primary statistic. Gaps 2,4,8,10 are exactly
identified forbidden gaps in the available exports. Their expected repeats form a rigorous lower bound
on the structural modulo-3 contribution. The exports do not isolate every possible forbidden gap, so
no complete modulo-3 decomposition is claimed.

## Limits

- The unrestricted shuffle is intentionally not a prime-admissible null; it measures total ordering
  departure, including congruence constraints.
- Candidate asymptotic levels are extrapolations from powers 10 through 100, not proofs of limits.
- Formal p-values are secondary because every window is far below expectation and the main issue is
  effect magnitude and structure.
- The analysis trusts the supplied data and does not rerun prime generation.
