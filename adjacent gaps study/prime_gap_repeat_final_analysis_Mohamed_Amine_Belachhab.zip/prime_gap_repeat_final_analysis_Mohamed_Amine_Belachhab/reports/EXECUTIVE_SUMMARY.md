# Executive summary — Total-count statistical study

## Primary result

Across **1,150 windows** and **46 scales**, the real sequence contains
**2,671,087** adjacent equal-gap repeats, compared with an unrestricted-shuffle expectation of
**5,252,242.348**. The total deficit is therefore **2,581,155.348 missing repeats**.

The count ratio is

\[
R/E=0.508561,
\]

so the pooled total-count suppression is **49.144%**.
All **1,150 of 1,150 windows** lie below their own shuffle expectation.

Relative to the number of adjacent gap pairs, the data contain:

- **1018.347** real repeats per 100,000 pairs;
- **2002.407** expected repeats per 100,000 pairs;
- **984.060** missing repeats per 100,000 pairs.

The fixed-grid bootstrap 95% interval for total suppression is
**49.088% to 49.200%**. The broader hierarchical interval,
which also treats the observed scales as a sample from a scale trajectory, is
**47.323% to 50.259%**.

## Scale behavior

Suppression declines from **52.336%** at
\(10^{10}\) to **43.818%** at
\(10^{100}\). The inverse-power count model

\[
\log \mu_w=\log E_w+\alpha+\beta/p
\]

has the best leave-one-power-out Poisson deviance among the tested simple models. Its fitted candidate
asymptotic count ratio is **0.560028**, corresponding to
**43.997% suppression**. This is a model-based
extrapolation, not a proven number-theoretic limit.

The fitted Poisson dispersion is **0.980**, and a
negative-binomial sensitivity fit estimates essentially zero extra dispersion. Thus the offset count
model describes the cross-window count variation unusually well after scale is included.

## What drives the scale change?

A Kitagawa decomposition of the change from \(10^{10}\) to \(10^{100}\) gives:

- net increase in the real/shuffle count ratio: **0.085173**;
- composition component: **-0.016924**;
- within-gap-group component: **0.102097**.

The within-group component is larger than the net change, while composition offsets part of it.
Therefore, the weakening of total suppression is **not mainly a mechanical consequence of small
forbidden gaps becoming rarer**. The real-to-shuffle ratio rises inside the broader gap ranges as well.

## Role of modulo 3

Modulo 3 remains an important explanatory mechanism, but it is not removed from the primary count.
The exactly identified forbidden gaps \(2,4,8,10\) contribute **871,861.603** missing
repeats, at least **33.778%** of the total deficit. This is a lower
bound because other forbidden gaps are embedded in mixed exported ranges.

The admissible special gaps \(6,12,18,30\) produce **1,678,531** real repeats against
**1,992,126.074** expected, a suppression of
**15.742%**. Thus the total effect is not exhausted by the
simplest forbidden-repeat rule.

## Hardy–Poisson

Corrected Hardy–Poisson tracks the unrestricted-shuffle expected count with a mean absolute relative
error of **0.513%** and correlation
**0.999996952**. It models marginal gap concentration extremely
well, but not the sequential ordering that lowers the real repeat count.
