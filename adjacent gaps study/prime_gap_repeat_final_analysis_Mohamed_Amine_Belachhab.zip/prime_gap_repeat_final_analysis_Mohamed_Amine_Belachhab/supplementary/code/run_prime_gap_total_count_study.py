from __future__ import annotations

import csv
import json
import math
import os
import platform
import shutil
import sys
import warnings
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scipy
from patsy import dmatrix
from scipy.optimize import minimize_scalar
from scipy.stats import (
    binomtest,
    chi2,
    kendalltau,
    norm,
    spearmanr,
    theilslopes,
    wilcoxon,
)
import sklearn
from sklearn.metrics import mean_absolute_error, mean_squared_error
import statsmodels
import statsmodels.api as sm
import statsmodels.formula.api as smf
from statsmodels.discrete.discrete_model import NegativeBinomial
from statsmodels.genmod.cov_struct import Autoregressive, Exchangeable, Independence
from statsmodels.genmod.families import Poisson
from statsmodels.stats.diagnostic import acorr_ljungbox, het_breuschpagan
from statsmodels.stats.multitest import multipletests
from statsmodels.stats.sandwich_covariance import cov_cluster_2groups
from statsmodels.stats.stattools import durbin_watson, jarque_bera

warnings.filterwarnings("ignore", category=RuntimeWarning)
warnings.filterwarnings("ignore", category=UserWarning)

SEED = 20260714
B = 50_000
ROOT = Path("/mnt/data")
PHASE1 = ROOT / "prime_gap_statistical_study_phase1"
REFINED = ROOT / "prime_gap_mod3_refined_data_package"
OUT = ROOT / "prime_gap_total_count_study_v2"
ZIP = ROOT / "prime_gap_total_count_study_v2.zip"

if OUT.exists():
    shutil.rmtree(OUT)
if ZIP.exists():
    ZIP.unlink()

for d in [
    "00_input_data",
    "01_analysis_ready",
    "02_inference",
    "03_count_models",
    "04_composition_and_mod3",
    "05_four_method_context",
    "06_figures",
    "07_report",
    "08_code",
    "09_workbook",
]:
    (OUT / d).mkdir(parents=True, exist_ok=True)

# -----------------------------------------------------------------------------
# Load trusted refined data (no recomputation of primes)
# -----------------------------------------------------------------------------
win = pd.read_csv(PHASE1 / "01_refined_v2/mod3_enhanced_window_v2.csv")
sgw = pd.read_csv(PHASE1 / "01_refined_v2/special_gap_window_including_inferred_8.csv")
ggw = pd.read_csv(PHASE1 / "01_refined_v2/gap_group_window_v2.csv")
fmw = pd.read_csv(REFINED / "04_four_method_context/four_method_window_with_mod3_context.csv")

# Snapshot the exact analysis inputs.
for src, name in [
    (PHASE1 / "01_refined_v2/mod3_enhanced_window_v2.csv", "window_input.csv"),
    (PHASE1 / "01_refined_v2/special_gap_window_including_inferred_8.csv", "special_gap_input.csv"),
    (PHASE1 / "01_refined_v2/gap_group_window_v2.csv", "gap_group_input.csv"),
    (REFINED / "04_four_method_context/four_method_window_with_mod3_context.csv", "four_method_input.csv"),
]:
    shutil.copy2(src, OUT / "00_input_data" / name)

# -----------------------------------------------------------------------------
# Primary count variables
# -----------------------------------------------------------------------------
win = win.copy()
win["adjacent_pairs"] = win["gap_count"] - 1
win["real_count"] = win["real_repeats"]
win["shuffle_expected_count"] = win["shuffle_expected_repeats"]
win["missing_repeat_count"] = win["shuffle_expected_count"] - win["real_count"]
win["real_rate"] = win["real_count"] / win["adjacent_pairs"]
win["shuffle_expected_rate"] = win["shuffle_expected_count"] / win["adjacent_pairs"]
win["missing_repeat_rate"] = win["missing_repeat_count"] / win["adjacent_pairs"]
win["real_per_100k_pairs"] = 100_000 * win["real_rate"]
win["expected_per_100k_pairs"] = 100_000 * win["shuffle_expected_rate"]
win["missing_per_100k_pairs"] = 100_000 * win["missing_repeat_rate"]
win["count_ratio_real_to_shuffle"] = win["real_count"] / win["shuffle_expected_count"]
win["suppression_total"] = 1 - win["count_ratio_real_to_shuffle"]
win["log_count_ratio"] = np.log(win["count_ratio_real_to_shuffle"])
win["inv_power"] = 1 / win["power"].astype(float)
win["inv_power2"] = win["inv_power"] ** 2
win["log_power"] = np.log(win["power"].astype(float))
win["power_centered_scaled"] = (win["power"] - win["power"].mean()) / win["power"].std(ddof=0)
win["log_expected_count"] = np.log(win["shuffle_expected_count"])

assert len(win) == 1150
assert win["power"].nunique() == 46
assert win.groupby("power").size().eq(25).all()
assert (win["real_count"] < win["shuffle_expected_count"]).all()
assert (win["missing_repeat_count"] > 0).all()
assert (win["adjacent_pairs"] > 0).all()

primary_cols = [
    "power", "window_id", "center", "lo", "hi", "prime_count", "gap_count", "adjacent_pairs",
    "real_count", "shuffle_expected_count", "missing_repeat_count",
    "real_rate", "shuffle_expected_rate", "missing_repeat_rate",
    "real_per_100k_pairs", "expected_per_100k_pairs", "missing_per_100k_pairs",
    "count_ratio_real_to_shuffle", "suppression_total", "log_count_ratio",
    "forbidden_2_4_8_10_expected", "forbidden_2_4_8_10_deficit_share_lower",
    "mod3_admissible_special_real_repeats", "mod3_admissible_special_unrestricted_expected_repeats",
]
win[primary_cols].to_csv(OUT / "01_analysis_ready/primary_count_window.csv", index=False)

# Scale summaries.
scale = win.groupby("power", as_index=False).agg(
    windows=("window_id", "size"),
    adjacent_pairs=("adjacent_pairs", "sum"),
    real_count=("real_count", "sum"),
    shuffle_expected_count=("shuffle_expected_count", "sum"),
    missing_repeat_count=("missing_repeat_count", "sum"),
    mean_window_real_count=("real_count", "mean"),
    median_window_real_count=("real_count", "median"),
    sd_window_real_count=("real_count", "std"),
    mean_window_expected_count=("shuffle_expected_count", "mean"),
    median_window_expected_count=("shuffle_expected_count", "median"),
    sd_window_expected_count=("shuffle_expected_count", "std"),
    mean_window_missing_count=("missing_repeat_count", "mean"),
    sd_window_missing_count=("missing_repeat_count", "std"),
    mean_window_ratio=("count_ratio_real_to_shuffle", "mean"),
    median_window_ratio=("count_ratio_real_to_shuffle", "median"),
    sd_window_ratio=("count_ratio_real_to_shuffle", "std"),
    min_window_ratio=("count_ratio_real_to_shuffle", "min"),
    max_window_ratio=("count_ratio_real_to_shuffle", "max"),
    windows_below_expectation=("missing_repeat_count", lambda x: int((x > 0).sum())),
    known_forbidden_expected=("forbidden_2_4_8_10_expected", "sum"),
    admissible_special_real=("mod3_admissible_special_real_repeats", "sum"),
    admissible_special_expected=("mod3_admissible_special_unrestricted_expected_repeats", "sum"),
)
scale["real_rate"] = scale["real_count"] / scale["adjacent_pairs"]
scale["shuffle_expected_rate"] = scale["shuffle_expected_count"] / scale["adjacent_pairs"]
scale["missing_repeat_rate"] = scale["missing_repeat_count"] / scale["adjacent_pairs"]
scale["real_per_100k_pairs"] = 100_000 * scale["real_rate"]
scale["expected_per_100k_pairs"] = 100_000 * scale["shuffle_expected_rate"]
scale["missing_per_100k_pairs"] = 100_000 * scale["missing_repeat_rate"]
scale["count_ratio_real_to_shuffle"] = scale["real_count"] / scale["shuffle_expected_count"]
scale["suppression_total"] = 1 - scale["count_ratio_real_to_shuffle"]
scale["log_count_ratio"] = np.log(scale["count_ratio_real_to_shuffle"])
scale["known_forbidden_share_of_total_deficit_lower_bound"] = scale["known_forbidden_expected"] / scale["missing_repeat_count"]
scale["known_forbidden_share_of_shuffle_expectation"] = scale["known_forbidden_expected"] / scale["shuffle_expected_count"]
scale["admissible_special_count_ratio"] = scale["admissible_special_real"] / scale["admissible_special_expected"]
scale["admissible_special_suppression"] = 1 - scale["admissible_special_count_ratio"]
scale["inv_power"] = 1 / scale["power"].astype(float)
scale.to_csv(OUT / "01_analysis_ready/primary_count_scale.csv", index=False)

# Window position summary.
window_pos = win.groupby("window_id", as_index=False).agg(
    powers=("power", "nunique"), adjacent_pairs=("adjacent_pairs", "sum"),
    real_count=("real_count", "sum"), shuffle_expected_count=("shuffle_expected_count", "sum"),
    missing_repeat_count=("missing_repeat_count", "sum"),
    mean_log_count_ratio=("log_count_ratio", "mean"), sd_log_count_ratio=("log_count_ratio", "std"),
)
window_pos["count_ratio_real_to_shuffle"] = window_pos["real_count"] / window_pos["shuffle_expected_count"]
window_pos["suppression_total"] = 1 - window_pos["count_ratio_real_to_shuffle"]
window_pos["missing_per_100k_pairs"] = 100_000 * window_pos["missing_repeat_count"] / window_pos["adjacent_pairs"]
window_pos.to_csv(OUT / "01_analysis_ready/window_position_summary.csv", index=False)

# -----------------------------------------------------------------------------
# Bootstrap machinery
# -----------------------------------------------------------------------------
metric_names = [
    "real_count", "shuffle_expected_count", "missing_repeat_count", "adjacent_pairs",
    "count_ratio_real_to_shuffle", "suppression_total", "log_count_ratio",
    "real_per_100k_pairs", "expected_per_100k_pairs", "missing_per_100k_pairs",
]


def aggregate_metrics_from_sums(sums: np.ndarray) -> np.ndarray:
    # columns R, E, D, pairs
    R, E, D, P = [sums[..., i] for i in range(4)]
    rr = R / E
    return np.stack([
        R, E, D, P, rr, 1 - rr, np.log(rr),
        100_000 * R / P, 100_000 * E / P, 100_000 * D / P,
    ], axis=-1)


def bca_interval(theta: float, boot: np.ndarray, jack: np.ndarray, alpha: float = 0.05):
    n = len(boot)
    prop = np.clip(np.mean(boot < theta), 1 / (2 * n), 1 - 1 / (2 * n))
    z0 = norm.ppf(prop)
    jm = jack.mean()
    numerator = np.sum((jm - jack) ** 3)
    denominator = 6 * (np.sum((jm - jack) ** 2) ** 1.5)
    acceleration = 0.0 if denominator == 0 else numerator / denominator
    zlo, zhi = norm.ppf(alpha / 2), norm.ppf(1 - alpha / 2)
    alo = norm.cdf(z0 + (z0 + zlo) / (1 - acceleration * (z0 + zlo)))
    ahi = norm.cdf(z0 + (z0 + zhi) / (1 - acceleration * (z0 + zhi)))
    alo, ahi = sorted((float(np.clip(alo, 0, 1)), float(np.clip(ahi, 0, 1))))
    return np.quantile(boot, [alo, ahi]), z0, acceleration


rng = np.random.default_rng(SEED)

# Scale-level BCa intervals, resampling the 25 windows within each fixed scale.
scale_ci_rows = []
base_cols = ["real_count", "shuffle_expected_count", "missing_repeat_count", "adjacent_pairs"]
for power, df in win.groupby("power", sort=True):
    a = df[base_cols].to_numpy(float)
    theta = aggregate_metrics_from_sums(a.sum(axis=0)[None, :])[0]
    ids = rng.integers(0, len(a), size=(B, len(a)))
    sums = a[ids].sum(axis=1)
    boot = aggregate_metrics_from_sums(sums)
    jack = np.stack([
        aggregate_metrics_from_sums(np.delete(a, i, axis=0).sum(axis=0)[None, :])[0]
        for i in range(len(a))
    ])
    for k, name in enumerate(metric_names):
        bounds, z0, acc = bca_interval(theta[k], boot[:, k], jack[:, k])
        scale_ci_rows.append({
            "power": int(power), "metric": name, "estimate": theta[k],
            "ci_low": bounds[0], "ci_high": bounds[1],
            "bootstrap_sd": boot[:, k].std(ddof=1), "bca_z0": z0,
            "bca_acceleration": acc, "resamples": B, "seed": SEED,
            "resampling_design": "25 windows resampled within fixed scale",
        })
scale_ci = pd.DataFrame(scale_ci_rows)
scale_ci.to_csv(OUT / "02_inference/scale_BCa_count_intervals_50000.csv", index=False)

# Global fixed-grid bootstrap: keep all 46 scales fixed and resample windows within each.
powers = np.array(sorted(win["power"].unique()))
arr = np.stack([
    win.loc[win.power.eq(p)].sort_values("window_id")[base_cols].to_numpy(float)
    for p in powers
])  # P x W x 4
point_sums = arr.sum(axis=(0, 1))
point_metrics = aggregate_metrics_from_sums(point_sums[None, :])[0]


def bootstrap_global(arr: np.ndarray, B: int, hierarchical: bool, seed: int, chunk: int = 1000):
    rg = np.random.default_rng(seed)
    P, W, K = arr.shape
    out = np.empty((B, len(metric_names)))
    start = 0
    while start < B:
        n = min(chunk, B - start)
        if hierarchical:
            pidx = rg.integers(0, P, size=(n, P))
            selected = arr[pidx]  # n x P x W x K
            widx = rg.integers(0, W, size=(n, P, W))
            sample = np.take_along_axis(selected, widx[..., None], axis=2)
        else:
            widx = rg.integers(0, W, size=(n, P, W))
            expanded = np.broadcast_to(arr, (n, P, W, K))
            sample = np.take_along_axis(expanded, widx[..., None], axis=2)
        sums = sample.sum(axis=(1, 2))
        out[start:start+n] = aggregate_metrics_from_sums(sums)
        start += n
    return out

fixed_boot = bootstrap_global(arr, B, hierarchical=False, seed=SEED + 1)
hier_boot = bootstrap_global(arr, B, hierarchical=True, seed=SEED + 2)

def summarize_boot(point: np.ndarray, boot: np.ndarray, design: str):
    rows = []
    for i, name in enumerate(metric_names):
        rows.append({
            "metric": name, "estimate": point[i],
            "ci_low_percentile": np.quantile(boot[:, i], 0.025),
            "ci_high_percentile": np.quantile(boot[:, i], 0.975),
            "bootstrap_mean": boot[:, i].mean(), "bootstrap_sd": boot[:, i].std(ddof=1),
            "resamples": len(boot), "seed": SEED, "resampling_design": design,
        })
    return pd.DataFrame(rows)

fixed_summary = summarize_boot(point_metrics, fixed_boot, "fixed 46-scale grid; resample 25 windows within every scale")
hier_summary = summarize_boot(point_metrics, hier_boot, "resample scales, then resample windows within selected scales")
fixed_summary.to_csv(OUT / "02_inference/global_fixed_grid_bootstrap_50000.csv", index=False)
hier_summary.to_csv(OUT / "02_inference/global_hierarchical_bootstrap_50000.csv", index=False)

# -----------------------------------------------------------------------------
# Exact consistency tests and robust nonparametric trend tests
# -----------------------------------------------------------------------------
all_windows_success = int((win["missing_repeat_count"] > 0).sum())
all_scales_success = int((scale["missing_repeat_count"] > 0).sum())
# Use logs for underflow-safe exact values.
log10_p_window_sign = -len(win) * math.log10(2)
log10_p_scale_sign = -len(scale) * math.log10(2)
wilc = wilcoxon(scale["log_count_ratio"], alternative="less", method="approx")
rho, rho_p = spearmanr(scale["power"], scale["log_count_ratio"])
tau, tau_p = kendalltau(scale["power"], scale["log_count_ratio"])
ts = theilslopes(scale["log_count_ratio"], scale["inv_power"], alpha=0.95)

test_rows = [
    {"test": "window-level sign test", "n": len(win), "successes": all_windows_success,
     "alternative": "real count < shuffle expectation", "statistic": all_windows_success,
     "p_value": 0.0, "log10_p_value": log10_p_window_sign,
     "note": "Exact p=2^-1150 under independent symmetric signs; reported only as consistency evidence."},
    {"test": "scale-level sign test", "n": len(scale), "successes": all_scales_success,
     "alternative": "pooled real count < pooled shuffle expectation", "statistic": all_scales_success,
     "p_value": 2 ** (-len(scale)), "log10_p_value": log10_p_scale_sign,
     "note": "More conservative than treating 1,150 windows as independent."},
    {"test": "Wilcoxon signed-rank across scales", "n": len(scale), "successes": np.nan,
     "alternative": "scale log count ratio < 0", "statistic": float(wilc.statistic),
     "p_value": float(wilc.pvalue), "log10_p_value": math.log10(float(wilc.pvalue)),
     "note": "Ranks the 46 scale-level log ratios."},
    {"test": "Spearman trend", "n": len(scale), "successes": np.nan,
     "alternative": "log ratio increases with power", "statistic": float(rho),
     "p_value": float(rho_p), "log10_p_value": math.log10(float(rho_p)),
     "note": "Positive trend means suppression weakens with scale."},
    {"test": "Kendall trend", "n": len(scale), "successes": np.nan,
     "alternative": "log ratio increases with power", "statistic": float(tau),
     "p_value": float(tau_p), "log10_p_value": math.log10(float(tau_p)),
     "note": "Rank-based monotonic trend."},
]
pd.DataFrame(test_rows).to_csv(OUT / "02_inference/sign_rank_and_trend_tests.csv", index=False)

pd.DataFrame([{
    "model": "Theil-Sen scale-level log ratio on 1/power",
    "slope": ts.slope, "intercept": ts.intercept,
    "slope_ci_low": ts.low_slope, "slope_ci_high": ts.high_slope,
    "candidate_asymptotic_count_ratio": math.exp(ts.intercept),
    "candidate_asymptotic_suppression": 1 - math.exp(ts.intercept),
}]).to_csv(OUT / "02_inference/theil_sen_robust_trend.csv", index=False)

# -----------------------------------------------------------------------------
# Random-effects meta-analysis of the 46 scale effects
# -----------------------------------------------------------------------------
logrr_ci = scale_ci.loc[scale_ci.metric.eq("log_count_ratio")].sort_values("power")
y = logrr_ci["estimate"].to_numpy(float)
se_y = logrr_ci["bootstrap_sd"].to_numpy(float)
k = len(y)


def reml_intercept_only(y, se):
    def objective(tau2):
        v = se**2 + tau2
        w = 1 / v
        mu = np.sum(w * y) / np.sum(w)
        return 0.5 * (np.sum(np.log(v)) + np.log(np.sum(w)) + np.sum((y - mu) ** 2 / v))
    upper = max(0.5, 10 * np.var(y))
    opt = minimize_scalar(objective, bounds=(0, upper), method="bounded")
    tau2 = max(0.0, float(opt.x))
    v = se**2 + tau2
    w = 1 / v
    mu = float(np.sum(w * y) / np.sum(w))
    se_mu = float(np.sqrt(1 / np.sum(w)))
    return mu, se_mu, tau2

mu_re, se_mu_re, tau2_re = reml_intercept_only(y, se_y)
wf = 1 / se_y**2
mu_fixed = float(np.sum(wf * y) / np.sum(wf))
se_fixed = float(np.sqrt(1 / np.sum(wf)))
Q = float(np.sum(wf * (y - mu_fixed) ** 2))
I2 = max(0.0, (Q - (k - 1)) / Q)
pred_se = math.sqrt(tau2_re + se_mu_re**2)
meta_rows = [
    {
        "model": "fixed-effect count-weighted scale synthesis", "k_scales": k,
        "mean_log_count_ratio": mu_fixed, "se": se_fixed, "tau2": 0.0,
        "count_ratio": math.exp(mu_fixed), "suppression": 1 - math.exp(mu_fixed),
        "ci_low_ratio": math.exp(mu_fixed - 1.96 * se_fixed),
        "ci_high_ratio": math.exp(mu_fixed + 1.96 * se_fixed),
        "prediction_low_ratio": np.nan, "prediction_high_ratio": np.nan,
        "Q": Q, "I2": I2,
    },
    {
        "model": "REML random-effects scale-balanced synthesis", "k_scales": k,
        "mean_log_count_ratio": mu_re, "se": se_mu_re, "tau2": tau2_re,
        "count_ratio": math.exp(mu_re), "suppression": 1 - math.exp(mu_re),
        "ci_low_ratio": math.exp(mu_re - 1.96 * se_mu_re),
        "ci_high_ratio": math.exp(mu_re + 1.96 * se_mu_re),
        "prediction_low_ratio": math.exp(mu_re - 1.96 * pred_se),
        "prediction_high_ratio": math.exp(mu_re + 1.96 * pred_se),
        "Q": Q, "I2": I2,
    },
]
pd.DataFrame(meta_rows).to_csv(OUT / "02_inference/random_effects_meta_analysis.csv", index=False)

# REML meta-regression on inverse power.
Xmeta = np.column_stack([np.ones(k), 1 / logrr_ci["power"].to_numpy(float)])

def reml_meta_regression(y, se, X):
    def objective(tau2):
        v = se**2 + tau2
        w = 1 / v
        XtWX = X.T @ (w[:, None] * X)
        beta = np.linalg.solve(XtWX, X.T @ (w * y))
        resid = y - X @ beta
        sign, logdet = np.linalg.slogdet(XtWX)
        return 0.5 * (np.sum(np.log(v)) + logdet + np.sum(w * resid**2))
    upper = max(0.5, 10 * np.var(y))
    opt = minimize_scalar(objective, bounds=(0, upper), method="bounded")
    tau2 = max(0.0, float(opt.x))
    v = se**2 + tau2
    w = 1 / v
    cov = np.linalg.inv(X.T @ (w[:, None] * X))
    beta = cov @ (X.T @ (w * y))
    resid = y - X @ beta
    return beta, cov, tau2, resid

beta_meta, cov_meta, tau2_meta, resid_meta = reml_meta_regression(y, se_y, Xmeta)
se_meta = np.sqrt(np.diag(cov_meta))
Q_resid = float(np.sum((resid_meta / se_y) ** 2))
I2_resid = max(0.0, (Q_resid - (k - Xmeta.shape[1])) / Q_resid)
meta_reg_rows = []
for name, est, se in zip(["intercept", "inv_power"], beta_meta, se_meta):
    meta_reg_rows.append({
        "term": name, "estimate": est, "se": se, "z": est / se,
        "p_value": 2 * norm.sf(abs(est / se)), "ci_low": est - 1.96 * se,
        "ci_high": est + 1.96 * se, "tau2_residual": tau2_meta,
        "residual_Q": Q_resid, "residual_I2": I2_resid,
        "candidate_asymptotic_ratio": math.exp(beta_meta[0]) if name == "intercept" else np.nan,
        "candidate_asymptotic_suppression": 1 - math.exp(beta_meta[0]) if name == "intercept" else np.nan,
    })
pd.DataFrame(meta_reg_rows).to_csv(OUT / "02_inference/meta_regression_inverse_power.csv", index=False)

# -----------------------------------------------------------------------------
# Count models: Poisson offset, two-way clustered inference, GEE, NB sensitivity
# -----------------------------------------------------------------------------
R = win["real_count"].to_numpy(float)
E = win["shuffle_expected_count"].to_numpy(float)
offset = np.log(E)

spline = np.asarray(dmatrix("bs(power, df=4, degree=3, include_intercept=False)", win, return_type="dataframe"))
designs = {
    "constant": np.ones((len(win), 1)),
    "inverse_power": sm.add_constant(win[["inv_power"]]).to_numpy(),
    "inverse_power_quadratic": sm.add_constant(win[["inv_power", "inv_power2"]]).to_numpy(),
    "log_power": sm.add_constant(win[["log_power"]]).to_numpy(),
    "linear_power": sm.add_constant(win[["power_centered_scaled"]]).to_numpy(),
    "spline_df4": np.column_stack([np.ones(len(win)), spline]),
}
term_names = {
    "constant": ["intercept"],
    "inverse_power": ["intercept", "inv_power"],
    "inverse_power_quadratic": ["intercept", "inv_power", "inv_power_squared"],
    "log_power": ["intercept", "log_power"],
    "linear_power": ["intercept", "power_centered_scaled"],
    "spline_df4": ["intercept"] + [f"spline_{i+1}" for i in range(spline.shape[1])],
}

model_coef_rows = []
model_summary_rows = []
model_fits = {}
for name, X in designs.items():
    fit = sm.GLM(R, X, family=Poisson(), offset=offset).fit()
    model_fits[name] = fit
    cov_tw, cov_power, cov_window = cov_cluster_2groups(
        fit, win["power"].to_numpy(), win["window_id"].to_numpy()
    )
    se_tw = np.sqrt(np.maximum(np.diag(cov_tw), 0))
    for term, est, se in zip(term_names[name], fit.params, se_tw):
        z = est / se if se > 0 else np.nan
        model_coef_rows.append({
            "model": name, "term": term, "estimate": est,
            "two_way_cluster_se": se, "z": z,
            "p_value": 2 * norm.sf(abs(z)) if np.isfinite(z) else np.nan,
            "ci_low": est - 1.96 * se if np.isfinite(se) else np.nan,
            "ci_high": est + 1.96 * se if np.isfinite(se) else np.nan,
            "clusters_power": scale.shape[0], "clusters_window_position": window_pos.shape[0],
        })
    model_summary_rows.append({
        "model": name, "n_windows": len(win), "parameters": X.shape[1],
        "log_likelihood": fit.llf, "aic": fit.aic, "bic_deviance": fit.bic_deviance,
        "deviance": fit.deviance, "pearson_dispersion": fit.pearson_chi2 / fit.df_resid,
        "candidate_asymptotic_ratio": math.exp(fit.params[0]) if name in ["inverse_power", "inverse_power_quadratic"] else np.nan,
        "candidate_asymptotic_suppression": 1 - math.exp(fit.params[0]) if name in ["inverse_power", "inverse_power_quadratic"] else np.nan,
    })

pd.DataFrame(model_coef_rows).to_csv(OUT / "03_count_models/poisson_offset_coefficients_two_way_clustered.csv", index=False)
pd.DataFrame(model_summary_rows).to_csv(OUT / "03_count_models/poisson_offset_model_summary.csv", index=False)

# Leave-one-power-out predictive comparison.
def poisson_deviance(y, mu):
    y = np.asarray(y, float); mu = np.asarray(mu, float)
    term = np.where(y > 0, y * np.log(y / mu) - (y - mu), mu)
    return float(2 * np.sum(term))

cv_rows = []
unique_powers = np.array(sorted(win["power"].unique()))
for name, X in designs.items():
    pred = np.empty(len(win))
    for p in unique_powers:
        train = win["power"].to_numpy() != p
        test = ~train
        fit = sm.GLM(R[train], X[train], family=Poisson(), offset=offset[train]).fit()
        pred[test] = fit.predict(X[test], offset=offset[test])
    scale_logrr_errors = []
    scale_count_ratio_errors = []
    for p in unique_powers:
        m = win["power"].to_numpy() == p
        observed_rr = R[m].sum() / E[m].sum()
        predicted_rr = pred[m].sum() / E[m].sum()
        scale_logrr_errors.append((math.log(observed_rr) - math.log(predicted_rr)) ** 2)
        scale_count_ratio_errors.append(abs(observed_rr - predicted_rr))
    cv_rows.append({
        "model": name, "lopo_poisson_deviance_total": poisson_deviance(R, pred),
        "lopo_poisson_deviance_per_window": poisson_deviance(R, pred) / len(win),
        "lopo_count_RMSE": math.sqrt(mean_squared_error(R, pred)),
        "lopo_count_MAE": mean_absolute_error(R, pred),
        "lopo_scale_log_ratio_RMSE": math.sqrt(np.mean(scale_logrr_errors)),
        "lopo_scale_ratio_MAE": np.mean(scale_count_ratio_errors),
    })
cv_df = pd.DataFrame(cv_rows).sort_values("lopo_poisson_deviance_per_window")
cv_df.to_csv(OUT / "03_count_models/count_model_leave_one_power_out_cv.csv", index=False)

# Primary inverse-power model predictions and diagnostics.
primary_fit = model_fits["inverse_power"]
primary_X = designs["inverse_power"]
win["primary_model_predicted_real_count"] = primary_fit.predict(primary_X, offset=offset)
win["primary_model_pearson_residual"] = (R - win["primary_model_predicted_real_count"]) / np.sqrt(win["primary_model_predicted_real_count"])
win["primary_model_deviance_residual"] = primary_fit.resid_deviance
win[[
    "power", "window_id", "real_count", "shuffle_expected_count", "primary_model_predicted_real_count",
    "primary_model_pearson_residual", "primary_model_deviance_residual",
]].to_csv(OUT / "03_count_models/primary_model_window_predictions_and_residuals.csv", index=False)

pred_scale = win.groupby("power", as_index=False).agg(
    observed_real_count=("real_count", "sum"), expected_shuffle_count=("shuffle_expected_count", "sum"),
    predicted_real_count=("primary_model_predicted_real_count", "sum"),
    mean_pearson_residual=("primary_model_pearson_residual", "mean"),
    sd_pearson_residual=("primary_model_pearson_residual", "std"),
)
pred_scale["observed_ratio"] = pred_scale["observed_real_count"] / pred_scale["expected_shuffle_count"]
pred_scale["predicted_ratio"] = pred_scale["predicted_real_count"] / pred_scale["expected_shuffle_count"]
pred_scale["observed_suppression"] = 1 - pred_scale["observed_ratio"]
pred_scale["predicted_suppression"] = 1 - pred_scale["predicted_ratio"]
pred_scale.to_csv(OUT / "03_count_models/primary_model_scale_predictions.csv", index=False)

resid_scale = pred_scale["observed_ratio"] - pred_scale["predicted_ratio"]
ljung = acorr_ljungbox(resid_scale, lags=[5, 10], return_df=True)
jb_stat, jb_p, skew, kurt = jarque_bera(primary_fit.resid_deviance)
bp_stat, bp_p, f_stat, f_p = het_breuschpagan(primary_fit.resid_deviance, primary_X)
resid_diag = pd.DataFrame([{
    "primary_model": "Poisson offset with inverse power",
    "pearson_dispersion": primary_fit.pearson_chi2 / primary_fit.df_resid,
    "deviance_per_df": primary_fit.deviance / primary_fit.df_resid,
    "durbin_watson_scale_ratio_residual": durbin_watson(resid_scale),
    "ljung_box_lag5_stat": ljung.loc[5, "lb_stat"], "ljung_box_lag5_p": ljung.loc[5, "lb_pvalue"],
    "ljung_box_lag10_stat": ljung.loc[10, "lb_stat"], "ljung_box_lag10_p": ljung.loc[10, "lb_pvalue"],
    "jarque_bera_stat_window_deviance_residual": jb_stat, "jarque_bera_p": jb_p,
    "residual_skew": skew, "residual_kurtosis": kurt,
    "breusch_pagan_stat": bp_stat, "breusch_pagan_p": bp_p,
    "breusch_pagan_F": f_stat, "breusch_pagan_F_p": f_p,
}])
resid_diag.to_csv(OUT / "03_count_models/residual_diagnostics.csv", index=False)

# GEE sensitivity (same mean structure, alternative working correlation).
gee_rows = []
for name, cov in [
    ("independence", Independence()),
    ("exchangeable", Exchangeable()),
    ("AR1", Autoregressive(grid=True)),
]:
    gee = sm.GEE(
        R, primary_X, groups=win["window_id"].to_numpy(), time=win["power"].to_numpy(),
        offset=offset, family=Poisson(), cov_struct=cov,
    ).fit(maxiter=300)
    for term, est, se, pval in zip(["intercept", "inv_power"], gee.params, gee.bse, gee.pvalues):
        gee_rows.append({
            "working_correlation": name, "term": term, "estimate": est, "robust_se": se,
            "p_value": pval, "ci_low": est - 1.96 * se, "ci_high": est + 1.96 * se,
            "candidate_asymptotic_ratio": math.exp(gee.params[0]) if term == "intercept" else np.nan,
            "candidate_asymptotic_suppression": 1 - math.exp(gee.params[0]) if term == "intercept" else np.nan,
        })
pd.DataFrame(gee_rows).to_csv(OUT / "03_count_models/GEE_working_correlation_sensitivity.csv", index=False)

# Negative-binomial sensitivity; alpha near zero means Poisson variance is adequate.
nb = NegativeBinomial(R, primary_X, offset=offset, loglike_method="nb2").fit(disp=False, maxiter=300)
nb_rows = []
for term, est, se in zip(["intercept", "inv_power", "alpha"], nb.params, nb.bse):
    nb_rows.append({
        "term": term, "estimate": est, "se": se, "z": est / se,
        "p_value": 2 * norm.sf(abs(est / se)), "ci_low": est - 1.96 * se,
        "ci_high": est + 1.96 * se,
    })
pd.DataFrame(nb_rows).to_csv(OUT / "03_count_models/negative_binomial_sensitivity.csv", index=False)

# Calibration model: is real count approximately proportional to E?
Xcal = sm.add_constant(win[["log_expected_count", "inv_power"]]).to_numpy()
cal = sm.GLM(R, Xcal, family=Poisson()).fit()
cal_cov, _, _ = cov_cluster_2groups(cal, win["power"].to_numpy(), win["window_id"].to_numpy())
cal_se = np.sqrt(np.maximum(np.diag(cal_cov), 0))
cal_terms = ["intercept", "log_expected_count_slope", "inv_power"]
cal_rows = []
for term, est, se in zip(cal_terms, cal.params, cal_se):
    null = 1.0 if term == "log_expected_count_slope" else 0.0
    z = (est - null) / se
    cal_rows.append({
        "term": term, "estimate": est, "two_way_cluster_se": se,
        "null_value_tested": null, "z": z, "p_value": 2 * norm.sf(abs(z)),
        "ci_low": est - 1.96 * se, "ci_high": est + 1.96 * se,
    })
pd.DataFrame(cal_rows).to_csv(OUT / "03_count_models/count_calibration_model.csv", index=False)

# Quantile regression across the full window distribution.
quant_rows = []
Xq = sm.add_constant(win[["inv_power"]])
for q in [0.10, 0.25, 0.50, 0.75, 0.90]:
    qr = sm.QuantReg(win["log_count_ratio"], Xq).fit(q=q, max_iter=10_000, p_tol=1e-9)
    for term in ["const", "inv_power"]:
        quant_rows.append({
            "quantile": q, "term": "intercept" if term == "const" else term,
            "estimate": qr.params[term], "se": qr.bse[term],
            "p_value": qr.pvalues[term], "ci_low": qr.conf_int().loc[term, 0],
            "ci_high": qr.conf_int().loc[term, 1],
            "candidate_asymptotic_ratio": math.exp(qr.params["const"]) if term == "const" else np.nan,
            "candidate_asymptotic_suppression": 1 - math.exp(qr.params["const"]) if term == "const" else np.nan,
        })
pd.DataFrame(quant_rows).to_csv(OUT / "02_inference/quantile_regression_window_distribution.csv", index=False)

# Fixed window-position effect after scale trend.
base_ols = smf.ols("log_count_ratio ~ inv_power", data=win).fit(cov_type="cluster", cov_kwds={"groups": win["power"]})
full_ols = smf.ols("log_count_ratio ~ inv_power + C(window_id)", data=win).fit(cov_type="cluster", cov_kwds={"groups": win["power"]})
window_terms = [t for t in full_ols.params.index if t.startswith("C(window_id)")]
Rmat = np.zeros((len(window_terms), len(full_ols.params)))
for i, t in enumerate(window_terms):
    Rmat[i, list(full_ols.params.index).index(t)] = 1
wald = full_ols.wald_test(Rmat, scalar=True)
pd.DataFrame([{
    "base_R2": base_ols.rsquared, "with_window_position_R2": full_ols.rsquared,
    "delta_R2": full_ols.rsquared - base_ols.rsquared,
    "joint_Wald_stat": float(wald.statistic), "joint_p_value": float(wald.pvalue),
    "max_absolute_window_position_log_ratio_coefficient": full_ols.params[window_terms].abs().max(),
}]).to_csv(OUT / "03_count_models/window_position_effect_test.csv", index=False)

# -----------------------------------------------------------------------------
# Gap groups: count contributions, trends, and composition decomposition
# -----------------------------------------------------------------------------
ggw = ggw.copy()
ggw["real_count"] = ggw["real_repeats_group"]
ggw["expected_count"] = ggw["expected_repeats_group"]
ggw["missing_count"] = ggw["expected_count"] - ggw["real_count"]
ggw["count_ratio"] = np.where(ggw["expected_count"] > 0, ggw["real_count"] / ggw["expected_count"], np.nan)
ggw["suppression"] = 1 - ggw["count_ratio"]
ggw["inv_power"] = 1 / ggw["power"].astype(float)

gg_scale = ggw.groupby(["power", "gap_group"], as_index=False).agg(
    gap_occurrences=("gap_count_group", "sum"), real_count=("real_count", "sum"),
    expected_count=("expected_count", "sum"), missing_count=("missing_count", "sum"),
)
gg_scale["count_ratio"] = np.where(gg_scale.expected_count > 0, gg_scale.real_count / gg_scale.expected_count, np.nan)
gg_scale["suppression"] = 1 - gg_scale["count_ratio"]
gg_scale = gg_scale.merge(scale[["power", "missing_repeat_count", "shuffle_expected_count", "real_count"]], on="power", suffixes=("", "_all"))
gg_scale["share_total_missing_count"] = gg_scale["missing_count"] / gg_scale["missing_repeat_count"]
gg_scale["share_total_expected_count"] = gg_scale["expected_count"] / gg_scale["shuffle_expected_count"]
gg_scale["share_total_real_count"] = gg_scale["real_count"] / gg_scale["real_count_all"]
gg_scale.to_csv(OUT / "04_composition_and_mod3/gap_group_by_scale.csv", index=False)

gg_pool = ggw.groupby("gap_group", as_index=False).agg(
    gap_occurrences=("gap_count_group", "sum"), real_count=("real_count", "sum"),
    expected_count=("expected_count", "sum"), missing_count=("missing_count", "sum"),
)
gg_pool["count_ratio"] = np.where(gg_pool.expected_count > 0, gg_pool.real_count / gg_pool.expected_count, np.nan)
gg_pool["suppression"] = 1 - gg_pool["count_ratio"]
gg_pool["share_total_missing_count"] = gg_pool["missing_count"] / win["missing_repeat_count"].sum()
gg_pool["share_total_expected_count"] = gg_pool["expected_count"] / win["shuffle_expected_count"].sum()
gg_pool["share_total_real_count"] = gg_pool["real_count"] / win["real_count"].sum()
gg_pool.to_csv(OUT / "04_composition_and_mod3/gap_group_pooled_count_contributions.csv", index=False)

# Count model for non-degenerate gap groups using offset log(expected).
group_model_data = ggw.loc[ggw.expected_count.gt(0) & ~ggw.gap_group.isin(["2", "4"])].copy()
group_model_data["cluster_id"] = group_model_data["gap_group"].astype(str) + "_" + group_model_data["window_id"].astype(str)
group_fit = smf.gee(
    "real_count ~ C(gap_group) * inv_power", groups="cluster_id", time="power",
    data=group_model_data, offset=np.log(group_model_data["expected_count"]),
    family=Poisson(), cov_struct=Autoregressive(grid=True),
).fit(maxiter=500)
group_coef = pd.DataFrame({
    "term": group_fit.params.index, "estimate": group_fit.params.values,
    "robust_se": group_fit.bse.values, "p_value": group_fit.pvalues.values,
    "ci_low": group_fit.conf_int()[0].values, "ci_high": group_fit.conf_int()[1].values,
})
interaction_mask = group_coef["term"].str.contains(":inv_power", regex=False)
if interaction_mask.any():
    group_coef.loc[interaction_mask, "p_value_FDR_BH"] = multipletests(
        group_coef.loc[interaction_mask, "p_value"], method="fdr_bh"
    )[1]
group_coef.to_csv(OUT / "04_composition_and_mod3/gap_group_GEE_count_model.csv", index=False)

# Kitagawa two-factor decomposition of total R/E change from p=10 to p=100.
def kitagawa_decomposition(df, p0=10, p1=100):
    d0 = df.loc[df.power.eq(p0)].set_index("gap_group").copy()
    d1 = df.loc[df.power.eq(p1)].set_index("gap_group").copy()
    cats = sorted(set(d0.index).union(d1.index))
    d0 = d0.reindex(cats).fillna(0)
    d1 = d1.reindex(cats).fillna(0)
    d0["w"] = d0.expected_count / d0.expected_count.sum()
    d1["w"] = d1.expected_count / d1.expected_count.sum()
    d0["q"] = np.where(d0.expected_count > 0, d0.real_count / d0.expected_count, np.nan)
    d1["q"] = np.where(d1.expected_count > 0, d1.real_count / d1.expected_count, np.nan)
    # If a category has zero expected mass at one endpoint, use the other endpoint's q;
    # this attributes its appearance/disappearance to composition rather than an undefined within effect.
    d0["q"] = d0["q"].fillna(d1["q"]).fillna(0)
    d1["q"] = d1["q"].fillna(d0["q"]).fillna(0)
    comp = 0.5 * (d1.q + d0.q) * (d1.w - d0.w)
    within = 0.5 * (d1.w + d0.w) * (d1.q - d0.q)
    out = pd.DataFrame({
        "gap_group": cats, "weight_p10": d0.w.values, "weight_p100": d1.w.values,
        "ratio_p10": d0.q.values, "ratio_p100": d1.q.values,
        "composition_component": comp.values, "within_group_component": within.values,
    })
    out["total_component"] = out["composition_component"] + out["within_group_component"]
    return out

kit = kitagawa_decomposition(gg_scale)
q10 = float(scale.loc[scale.power.eq(10), "count_ratio_real_to_shuffle"].iloc[0])
q100 = float(scale.loc[scale.power.eq(100), "count_ratio_real_to_shuffle"].iloc[0])
kit["total_ratio_change_p100_minus_p10"] = q100 - q10
kit["composition_total"] = kit["composition_component"].sum()
kit["within_group_total"] = kit["within_group_component"].sum()
kit.to_csv(OUT / "04_composition_and_mod3/kitagawa_decomposition_power10_to_power100.csv", index=False)

# -----------------------------------------------------------------------------
# Special gaps and modulo-3 explanation (secondary, not a correction)
# -----------------------------------------------------------------------------
sgw = sgw.copy()
sgw["real_count"] = sgw["real_same_gap_repeats"]
sgw["expected_count"] = sgw["expected_same_gap_repeats"]
sgw["missing_count"] = sgw["expected_count"] - sgw["real_count"]
sgw["count_ratio"] = np.where(sgw.expected_count > 0, sgw.real_count / sgw.expected_count, np.nan)
sgw["suppression"] = 1 - sgw["count_ratio"]
sgw["inv_power"] = 1 / sgw["power"].astype(float)

sg_scale = sgw.groupby(["power", "gap", "mod3_class"], as_index=False).agg(
    gap_occurrences=("gap_count", "sum"), real_count=("real_count", "sum"),
    expected_count=("expected_count", "sum"), missing_count=("missing_count", "sum"),
)
sg_scale["count_ratio"] = np.where(sg_scale.expected_count > 0, sg_scale.real_count / sg_scale.expected_count, np.nan)
sg_scale["suppression"] = 1 - sg_scale["count_ratio"]
sg_scale.to_csv(OUT / "04_composition_and_mod3/special_gap_by_scale.csv", index=False)

sg_pool = sgw.groupby(["gap", "mod3_class"], as_index=False).agg(
    gap_occurrences=("gap_count", "sum"), real_count=("real_count", "sum"),
    expected_count=("expected_count", "sum"), missing_count=("missing_count", "sum"),
)
sg_pool["count_ratio"] = np.where(sg_pool.expected_count > 0, sg_pool.real_count / sg_pool.expected_count, np.nan)
sg_pool["suppression"] = 1 - sg_pool["count_ratio"]
sg_pool["share_total_missing_count"] = sg_pool["missing_count"] / win["missing_repeat_count"].sum()
sg_pool["share_total_expected_count"] = sg_pool["expected_count"] / win["shuffle_expected_count"].sum()
sg_pool["share_total_real_count"] = sg_pool["real_count"] / win["real_count"].sum()
sg_pool.to_csv(OUT / "04_composition_and_mod3/special_gap_pooled_count_contributions.csv", index=False)

known_forbidden_scale = scale[[
    "power", "known_forbidden_expected", "missing_repeat_count", "shuffle_expected_count",
    "known_forbidden_share_of_total_deficit_lower_bound", "known_forbidden_share_of_shuffle_expectation",
    "admissible_special_real", "admissible_special_expected", "admissible_special_suppression",
]].copy()
known_forbidden_scale.to_csv(OUT / "04_composition_and_mod3/mod3_explanatory_by_scale.csv", index=False)

known_forbidden_total = win["forbidden_2_4_8_10_expected"].sum()
adm_real_total = win["mod3_admissible_special_real_repeats"].sum()
adm_expected_total = win["mod3_admissible_special_unrestricted_expected_repeats"].sum()
mod3_summary = pd.DataFrame([
    {
        "quantity": "known forbidden gaps 2,4,8,10 expected repeats",
        "count": known_forbidden_total,
        "share_total_missing_count": known_forbidden_total / win["missing_repeat_count"].sum(),
        "share_total_shuffle_expectation": known_forbidden_total / win["shuffle_expected_count"].sum(),
        "interpretation": "Exact lower bound on the modulo-3 structural component available from exported gaps.",
    },
    {
        "quantity": "admissible special gaps 6,12,18,30 real repeats",
        "count": adm_real_total,
        "share_total_missing_count": np.nan,
        "share_total_shuffle_expectation": adm_expected_total / win["shuffle_expected_count"].sum(),
        "interpretation": "Observed count for selected mod-3-admissible gaps.",
    },
    {
        "quantity": "admissible special gaps 6,12,18,30 shuffle expectation",
        "count": adm_expected_total,
        "share_total_missing_count": (adm_expected_total - adm_real_total) / win["missing_repeat_count"].sum(),
        "share_total_shuffle_expectation": adm_expected_total / win["shuffle_expected_count"].sum(),
        "interpretation": "Unrestricted-shuffle expectation; these gaps remain suppressed despite being mod-3-admissible.",
    },
])
mod3_summary.to_csv(OUT / "04_composition_and_mod3/mod3_explanatory_global_summary.csv", index=False)

# Admissible special-gap GEE count model.
adm = sgw.loc[sgw.mod3_class.eq("admissible") & sgw.expected_count.gt(0)].copy()
adm["cluster_id"] = adm["gap"].astype(str) + "_" + adm["window_id"].astype(str)
adm_fit = smf.gee(
    "real_count ~ C(gap) * inv_power", groups="cluster_id", time="power",
    data=adm, offset=np.log(adm["expected_count"]), family=Poisson(),
    cov_struct=Autoregressive(grid=True),
).fit(maxiter=500)
adm_coef = pd.DataFrame({
    "term": adm_fit.params.index, "estimate": adm_fit.params.values,
    "robust_se": adm_fit.bse.values, "p_value": adm_fit.pvalues.values,
    "ci_low": adm_fit.conf_int()[0].values, "ci_high": adm_fit.conf_int()[1].values,
})
interaction_mask = adm_coef["term"].str.contains(":inv_power", regex=False)
if interaction_mask.any():
    adm_coef.loc[interaction_mask, "p_value_FDR_BH"] = multipletests(
        adm_coef.loc[interaction_mask, "p_value"], method="fdr_bh"
    )[1]
adm_coef.to_csv(OUT / "04_composition_and_mod3/admissible_special_gap_GEE_count_model.csv", index=False)

# -----------------------------------------------------------------------------
# Four-method count context
# -----------------------------------------------------------------------------
fm = fmw.copy()
fm["real"] = fm["real_repeats"]
fm["shuffle"] = fm["exact_shuffle_expected_repeats"]
fm["hardy_poisson"] = fm["corrected_hardy_poisson_expected_repeats"]
fm["pure_hardy"] = fm["corrected_pure_hardy_expected_repeats"]

method_rows = []
for method in ["shuffle", "hardy_poisson", "pure_hardy"]:
    pred = fm[method].to_numpy(float)
    obs = fm["real"].to_numpy(float)
    rel = pred / obs
    method_rows.append({
        "method": method, "total_predicted_count": pred.sum(), "total_real_count": obs.sum(),
        "pooled_predicted_to_real_ratio": pred.sum() / obs.sum(),
        "mean_window_predicted_to_real_ratio": rel.mean(),
        "median_window_predicted_to_real_ratio": np.median(rel),
        "MAE_count": np.mean(np.abs(pred - obs)), "RMSE_count": np.sqrt(np.mean((pred - obs) ** 2)),
        "mean_absolute_relative_error_vs_real": np.mean(np.abs(pred / obs - 1)),
        "pearson_correlation_with_real": np.corrcoef(pred, obs)[0, 1],
    })
pd.DataFrame(method_rows).to_csv(OUT / "05_four_method_context/method_count_comparison_vs_real.csv", index=False)

fm["hp_to_shuffle_ratio"] = fm["hardy_poisson"] / fm["shuffle"]
fm["hp_minus_shuffle"] = fm["hardy_poisson"] - fm["shuffle"]
fm["hp_relative_error_vs_shuffle"] = fm["hp_to_shuffle_ratio"] - 1
fm["log_hp"] = np.log(fm["hardy_poisson"])
fm["log_shuffle"] = np.log(fm["shuffle"])
hpcal = smf.ols("log_hp ~ log_shuffle", data=fm).fit(cov_type="HC3")
hp_summary = pd.DataFrame([{
    "windows": len(fm), "pooled_HP_to_shuffle_ratio": fm.hardy_poisson.sum() / fm.shuffle.sum(),
    "mean_HP_to_shuffle_ratio": fm.hp_to_shuffle_ratio.mean(),
    "median_HP_to_shuffle_ratio": fm.hp_to_shuffle_ratio.median(),
    "mean_relative_error": fm.hp_relative_error_vs_shuffle.mean(),
    "mean_absolute_relative_error": fm.hp_relative_error_vs_shuffle.abs().mean(),
    "relative_RMSE": np.sqrt(np.mean(fm.hp_relative_error_vs_shuffle**2)),
    "maximum_absolute_relative_error": fm.hp_relative_error_vs_shuffle.abs().max(),
    "pearson_correlation": np.corrcoef(fm.hardy_poisson, fm.shuffle)[0, 1],
    "log_calibration_intercept": hpcal.params["Intercept"],
    "log_calibration_intercept_HC3_se": hpcal.bse["Intercept"],
    "log_calibration_slope": hpcal.params["log_shuffle"],
    "log_calibration_slope_HC3_se": hpcal.bse["log_shuffle"],
    "R2": hpcal.rsquared,
}])
hp_summary.to_csv(OUT / "05_four_method_context/hardy_poisson_vs_shuffle_calibration.csv", index=False)

fm_scale = fm.groupby("power", as_index=False).agg(
    real=("real", "sum"), shuffle=("shuffle", "sum"),
    hardy_poisson=("hardy_poisson", "sum"), pure_hardy=("pure_hardy", "sum"),
)
for method in ["shuffle", "hardy_poisson", "pure_hardy"]:
    fm_scale[f"{method}_to_real"] = fm_scale[method] / fm_scale["real"]
fm_scale["hardy_poisson_to_shuffle"] = fm_scale["hardy_poisson"] / fm_scale["shuffle"]
fm_scale.to_csv(OUT / "05_four_method_context/four_method_counts_by_scale.csv", index=False)

# -----------------------------------------------------------------------------
# Figures (each figure in its own file, default matplotlib colors/styles)
# -----------------------------------------------------------------------------
figdir = OUT / "06_figures"

# 1 Total counts.
plt.figure(figsize=(9, 5.5))
plt.semilogy(scale.power, scale.shuffle_expected_count, marker="o", label="Unrestricted-shuffle expectation")
plt.semilogy(scale.power, scale.real_count, marker="o", label="Real repeats")
plt.semilogy(scale.power, scale.missing_repeat_count, marker="o", label="Missing repeats (E-R)")
plt.xlabel("Power p in 10^p")
plt.ylabel("Total count across 25 windows (log scale)")
plt.title("Adjacent equal-gap repeat counts by scale")
plt.legend()
plt.tight_layout()
plt.savefig(figdir / "01_total_counts_vs_scale.png", dpi=220)
plt.close()
scale[["power", "real_count", "shuffle_expected_count", "missing_repeat_count"]].to_csv(figdir / "01_total_counts_vs_scale_data.csv", index=False)

# 2 Rates.
plt.figure(figsize=(9, 5.5))
plt.plot(scale.power, scale.expected_per_100k_pairs, marker="o", label="Shuffle expected")
plt.plot(scale.power, scale.real_per_100k_pairs, marker="o", label="Real")
plt.plot(scale.power, scale.missing_per_100k_pairs, marker="o", label="Missing")
plt.xlabel("Power p in 10^p")
plt.ylabel("Repeats per 100,000 adjacent gap pairs")
plt.title("Count-normalized repeat rates")
plt.legend()
plt.tight_layout()
plt.savefig(figdir / "02_repeat_rates_per_100k.png", dpi=220)
plt.close()
scale[["power", "real_per_100k_pairs", "expected_per_100k_pairs", "missing_per_100k_pairs"]].to_csv(figdir / "02_repeat_rates_per_100k_data.csv", index=False)

# 3 Suppression with BCa intervals.
supp_ci = scale_ci.loc[scale_ci.metric.eq("suppression_total")].sort_values("power")
plt.figure(figsize=(9, 5.5))
plt.plot(supp_ci.power, 100 * supp_ci.estimate, marker="o", label="Pooled suppression")
plt.fill_between(supp_ci.power, 100 * supp_ci.ci_low, 100 * supp_ci.ci_high, alpha=0.25, label="95% BCa interval")
plt.xlabel("Power p in 10^p")
plt.ylabel("Suppression (%)")
plt.title("Total count suppression relative to unrestricted shuffle")
plt.legend()
plt.tight_layout()
plt.savefig(figdir / "03_total_suppression_BCa.png", dpi=220)
plt.close()
supp_ci.to_csv(figdir / "03_total_suppression_BCa_data.csv", index=False)

# 4 Selected-scale distributions.
selected = [10, 20, 40, 60, 80, 100]
box_data = [win.loc[win.power.eq(p), "count_ratio_real_to_shuffle"].to_numpy() for p in selected]
plt.figure(figsize=(9, 5.5))
plt.boxplot(box_data, tick_labels=[str(p) for p in selected], showmeans=True)
plt.xlabel("Power p")
plt.ylabel("Real count / shuffle expected count")
plt.title("Window-level count-ratio distributions at selected scales")
plt.tight_layout()
plt.savefig(figdir / "04_window_ratio_distributions.png", dpi=220)
plt.close()
win.loc[win.power.isin(selected), ["power", "window_id", "count_ratio_real_to_shuffle"]].to_csv(figdir / "04_window_ratio_distributions_data.csv", index=False)

# 5 Primary model fit.
plt.figure(figsize=(9, 5.5))
plt.plot(pred_scale.power, pred_scale.observed_ratio, marker="o", label="Observed pooled ratio")
plt.plot(pred_scale.power, pred_scale.predicted_ratio, label="Inverse-power Poisson-offset fit")
plt.xlabel("Power p in 10^p")
plt.ylabel("Real count / shuffle expected count")
plt.title("Count-ratio trend and primary model fit")
plt.legend()
plt.tight_layout()
plt.savefig(figdir / "05_primary_count_model_fit.png", dpi=220)
plt.close()
pred_scale.to_csv(figdir / "05_primary_count_model_fit_data.csv", index=False)

# 6 Pooled gap-group missing-count contributions.
gg_plot = gg_pool.sort_values("share_total_missing_count", ascending=True)
plt.figure(figsize=(9, 6))
plt.barh(gg_plot.gap_group, 100 * gg_plot.share_total_missing_count)
plt.xlabel("Share of all missing repeats (%)")
plt.ylabel("Gap group")
plt.title("Which gap ranges generate the total count deficit?")
plt.tight_layout()
plt.savefig(figdir / "06_gap_group_missing_count_contributions.png", dpi=220)
plt.close()
gg_plot.to_csv(figdir / "06_gap_group_missing_count_contributions_data.csv", index=False)

# 7 Gap-group suppression heatmap.
pivot = gg_scale.pivot(index="gap_group", columns="power", values="suppression")
order = ["2", "4", "6", "8-12", "14-24", "26-48", "50-100", "102-250", "252-500", "502+"]
pivot = pivot.reindex(order)
plt.figure(figsize=(12, 5.8))
img = plt.imshow(100 * pivot.to_numpy(), aspect="auto", interpolation="nearest")
plt.colorbar(img, label="Suppression (%)")
plt.yticks(np.arange(len(pivot.index)), pivot.index)
xticks = np.arange(0, len(pivot.columns), 5)
plt.xticks(xticks, pivot.columns.to_numpy()[xticks], rotation=45)
plt.xlabel("Power p")
plt.ylabel("Gap group")
plt.title("Suppression by gap range and scale")
plt.tight_layout()
plt.savefig(figdir / "07_gap_group_suppression_heatmap.png", dpi=220)
plt.close()
pivot.to_csv(figdir / "07_gap_group_suppression_heatmap_data.csv")

# 8 Kitagawa decomposition.
kit_plot = kit.sort_values("total_component")
plt.figure(figsize=(9, 6))
plt.barh(kit_plot.gap_group, kit_plot.composition_component, label="Composition")
plt.barh(kit_plot.gap_group, kit_plot.within_group_component, left=kit_plot.composition_component, label="Within-group")
plt.axvline(0, linewidth=1)
plt.xlabel("Contribution to change in real/shuffle count ratio, p=10 to p=100")
plt.ylabel("Gap group")
plt.title("Why total suppression weakens with scale")
plt.legend()
plt.tight_layout()
plt.savefig(figdir / "08_kitagawa_scale_change_decomposition.png", dpi=220)
plt.close()
kit.to_csv(figdir / "08_kitagawa_scale_change_decomposition_data.csv", index=False)

# 9 Modulo-3 explanatory share.
plt.figure(figsize=(9, 5.5))
plt.plot(scale.power, 100 * scale.known_forbidden_share_of_total_deficit_lower_bound, marker="o", label="Known forbidden share of deficit (lower bound)")
plt.plot(scale.power, 100 * scale.admissible_special_suppression, marker="o", label="Suppression for admissible gaps 6,12,18,30")
plt.xlabel("Power p in 10^p")
plt.ylabel("Percent")
plt.title("Modulo-3 as an explanation, not a removed component")
plt.legend()
plt.tight_layout()
plt.savefig(figdir / "09_mod3_explanatory_layers.png", dpi=220)
plt.close()
known_forbidden_scale.to_csv(figdir / "09_mod3_explanatory_layers_data.csv", index=False)

# 10 Hardy-Poisson calibration.
plt.figure(figsize=(6.5, 6.5))
plt.scatter(fm.shuffle, fm.hardy_poisson, s=10, alpha=0.5)
lo = min(fm.shuffle.min(), fm.hardy_poisson.min())
hi = max(fm.shuffle.max(), fm.hardy_poisson.max())
plt.plot([lo, hi], [lo, hi], linestyle="--", label="Identity")
plt.xscale("log")
plt.yscale("log")
plt.xlabel("Exact-shuffle expected count")
plt.ylabel("Corrected Hardy-Poisson expected count")
plt.title("Hardy-Poisson reproduces the marginal count expectation")
plt.legend()
plt.tight_layout()
plt.savefig(figdir / "10_hardy_poisson_vs_shuffle_counts.png", dpi=220)
plt.close()
fm[["power", "window_id", "shuffle", "hardy_poisson", "hp_to_shuffle_ratio"]].to_csv(figdir / "10_hardy_poisson_vs_shuffle_counts_data.csv", index=False)

# -----------------------------------------------------------------------------
# Key results and reports
# -----------------------------------------------------------------------------
def boot_lookup(df, metric):
    r = df.loc[df.metric.eq(metric)].iloc[0]
    return float(r.estimate), float(r.ci_low_percentile), float(r.ci_high_percentile)

pooled_R = float(win.real_count.sum())
pooled_E = float(win.shuffle_expected_count.sum())
pooled_D = pooled_E - pooled_R
pooled_pairs = float(win.adjacent_pairs.sum())
pooled_rr = pooled_R / pooled_E
pooled_supp = 1 - pooled_rr
fixed_supp = boot_lookup(fixed_summary, "suppression_total")
hier_supp = boot_lookup(hier_summary, "suppression_total")
fixed_missing_rate = boot_lookup(fixed_summary, "missing_per_100k_pairs")
hier_missing_rate = boot_lookup(hier_summary, "missing_per_100k_pairs")
primary_coef = pd.DataFrame(model_coef_rows)
primary_intercept = primary_coef.query("model == 'inverse_power' and term == 'intercept'").iloc[0]
primary_slope = primary_coef.query("model == 'inverse_power' and term == 'inv_power'").iloc[0]
kit_comp_total = float(kit.composition_component.sum())
kit_within_total = float(kit.within_group_component.sum())

key = {
    "dataset": {"windows": len(win), "scales": int(win.power.nunique()), "windows_per_scale": 25},
    "primary_counts": {
        "real_repeats": pooled_R, "shuffle_expected_repeats": pooled_E,
        "missing_repeats": pooled_D, "adjacent_pairs": pooled_pairs,
        "real_to_shuffle_count_ratio": pooled_rr, "total_suppression": pooled_supp,
        "real_per_100k_pairs": 100_000 * pooled_R / pooled_pairs,
        "expected_per_100k_pairs": 100_000 * pooled_E / pooled_pairs,
        "missing_per_100k_pairs": 100_000 * pooled_D / pooled_pairs,
        "all_windows_below_expectation": bool((win.real_count < win.shuffle_expected_count).all()),
    },
    "bootstrap": {
        "fixed_grid_suppression_95pct": [fixed_supp[1], fixed_supp[2]],
        "hierarchical_suppression_95pct": [hier_supp[1], hier_supp[2]],
        "fixed_grid_missing_per_100k_95pct": [fixed_missing_rate[1], fixed_missing_rate[2]],
        "hierarchical_missing_per_100k_95pct": [hier_missing_rate[1], hier_missing_rate[2]],
    },
    "scale_endpoints": {
        "power10_suppression": float(scale.loc[scale.power.eq(10), "suppression_total"].iloc[0]),
        "power100_suppression": float(scale.loc[scale.power.eq(100), "suppression_total"].iloc[0]),
        "power10_missing_per_100k": float(scale.loc[scale.power.eq(10), "missing_per_100k_pairs"].iloc[0]),
        "power100_missing_per_100k": float(scale.loc[scale.power.eq(100), "missing_per_100k_pairs"].iloc[0]),
    },
    "primary_count_model": {
        "form": "log E[real_count] = log(shuffle_expected_count) + intercept + beta/power",
        "intercept": float(primary_intercept.estimate), "intercept_two_way_cluster_se": float(primary_intercept.two_way_cluster_se),
        "inv_power_slope": float(primary_slope.estimate), "inv_power_slope_two_way_cluster_se": float(primary_slope.two_way_cluster_se),
        "candidate_asymptotic_count_ratio": math.exp(float(primary_intercept.estimate)),
        "candidate_asymptotic_suppression": 1 - math.exp(float(primary_intercept.estimate)),
        "pearson_dispersion": float(primary_fit.pearson_chi2 / primary_fit.df_resid),
        "best_LOPO_model_by_poisson_deviance": str(cv_df.iloc[0].model),
    },
    "scale_balanced_meta_analysis": {
        "random_effects_ratio": math.exp(mu_re), "random_effects_suppression": 1 - math.exp(mu_re),
        "random_effects_ratio_95pct": [math.exp(mu_re - 1.96 * se_mu_re), math.exp(mu_re + 1.96 * se_mu_re)],
        "prediction_interval_ratio": [math.exp(mu_re - 1.96 * pred_se), math.exp(mu_re + 1.96 * pred_se)],
        "I2_before_trend": I2, "residual_I2_after_inverse_power_meta_regression": I2_resid,
    },
    "composition_change_power10_to_power100": {
        "real_to_shuffle_ratio_change": q100 - q10,
        "composition_component": kit_comp_total,
        "within_group_component": kit_within_total,
        "within_group_fraction_of_net_change": kit_within_total / (q100 - q10),
        "interpretation": "Within-group ratios more than explain the observed increase; composition offsets part of it.",
    },
    "mod3_explanation": {
        "known_forbidden_2_4_8_10_count": known_forbidden_total,
        "known_forbidden_share_total_missing_lower_bound": known_forbidden_total / pooled_D,
        "known_forbidden_share_total_shuffle_expectation": known_forbidden_total / pooled_E,
        "admissible_6_12_18_30_real": adm_real_total,
        "admissible_6_12_18_30_expected": adm_expected_total,
        "admissible_6_12_18_30_suppression": 1 - adm_real_total / adm_expected_total,
    },
    "hardy_poisson": hp_summary.iloc[0].to_dict(),
}
with open(OUT / "07_report/key_results.json", "w", encoding="utf-8") as f:
    json.dump(key, f, indent=2, default=float)

# Executive summary.
exec_summary = f"""# Executive summary — Total-count statistical study

## Primary result

Across **{len(win):,} windows** and **{int(win.power.nunique())} scales**, the real sequence contains
**{pooled_R:,.0f}** adjacent equal-gap repeats, compared with an unrestricted-shuffle expectation of
**{pooled_E:,.3f}**. The total deficit is therefore **{pooled_D:,.3f} missing repeats**.

The count ratio is

\[
R/E={pooled_rr:.6f},
\]

so the pooled total-count suppression is **{100*pooled_supp:.3f}%**.
All **1,150 of 1,150 windows** lie below their own shuffle expectation.

Relative to the number of adjacent gap pairs, the data contain:

- **{100_000*pooled_R/pooled_pairs:.3f}** real repeats per 100,000 pairs;
- **{100_000*pooled_E/pooled_pairs:.3f}** expected repeats per 100,000 pairs;
- **{100_000*pooled_D/pooled_pairs:.3f}** missing repeats per 100,000 pairs.

The fixed-grid bootstrap 95% interval for total suppression is
**{100*fixed_supp[1]:.3f}% to {100*fixed_supp[2]:.3f}%**. The broader hierarchical interval,
which also treats the observed scales as a sample from a scale trajectory, is
**{100*hier_supp[1]:.3f}% to {100*hier_supp[2]:.3f}%**.

## Scale behavior

Suppression declines from **{100*scale.loc[scale.power.eq(10), 'suppression_total'].iloc[0]:.3f}%** at
\(10^{{10}}\) to **{100*scale.loc[scale.power.eq(100), 'suppression_total'].iloc[0]:.3f}%** at
\(10^{{100}}\). The inverse-power count model

\[
\log \mu_w=\log E_w+\\alpha+\\beta/p
\]

has the best leave-one-power-out Poisson deviance among the tested simple models. Its fitted candidate
asymptotic count ratio is **{math.exp(float(primary_intercept.estimate)):.6f}**, corresponding to
**{100*(1-math.exp(float(primary_intercept.estimate))):.3f}% suppression**. This is a model-based
extrapolation, not a proven number-theoretic limit.

The fitted Poisson dispersion is **{primary_fit.pearson_chi2/primary_fit.df_resid:.3f}**, and a
negative-binomial sensitivity fit estimates essentially zero extra dispersion. Thus the offset count
model describes the cross-window count variation unusually well after scale is included.

## What drives the scale change?

A Kitagawa decomposition of the change from \(10^{{10}}\) to \(10^{{100}}\) gives:

- net increase in the real/shuffle count ratio: **{q100-q10:.6f}**;
- composition component: **{kit_comp_total:.6f}**;
- within-gap-group component: **{kit_within_total:.6f}**.

The within-group component is larger than the net change, while composition offsets part of it.
Therefore, the weakening of total suppression is **not mainly a mechanical consequence of small
forbidden gaps becoming rarer**. The real-to-shuffle ratio rises inside the broader gap ranges as well.

## Role of modulo 3

Modulo 3 remains an important explanatory mechanism, but it is not removed from the primary count.
The exactly identified forbidden gaps \(2,4,8,10\) contribute **{known_forbidden_total:,.3f}** missing
repeats, at least **{100*known_forbidden_total/pooled_D:.3f}%** of the total deficit. This is a lower
bound because other forbidden gaps are embedded in mixed exported ranges.

The admissible special gaps \(6,12,18,30\) produce **{adm_real_total:,.0f}** real repeats against
**{adm_expected_total:,.3f}** expected, a suppression of
**{100*(1-adm_real_total/adm_expected_total):.3f}%**. Thus the total effect is not exhausted by the
simplest forbidden-repeat rule.

## Hardy–Poisson

Corrected Hardy–Poisson tracks the unrestricted-shuffle expected count with a mean absolute relative
error of **{100*hp_summary.iloc[0]['mean_absolute_relative_error']:.3f}%** and correlation
**{hp_summary.iloc[0]['pearson_correlation']:.9f}**. It models marginal gap concentration extremely
well, but not the sequential ordering that lowers the real repeat count.
"""
(OUT / "07_report/EXECUTIVE_SUMMARY.md").write_text(exec_summary, encoding="utf-8")

methodology = """# Methodology and interpretation rules

## Primary estimand

The study keeps every exported gap, including gaps whose repeated occurrence is structurally forbidden
modulo 3. The primary question is conditional and empirical:

> Given the exact multiset of gaps in each window, how many adjacent equal-gap repeats occur in the real
> ordering compared with an unrestricted random ordering?

The primary quantities are the real count R, unrestricted-shuffle expectation E, missing count E-R,
count ratio R/E, proportional suppression 1-R/E, and all three counts normalized per 100,000 adjacent
pairs.

## Uncertainty

The arithmetic counts themselves are fixed. Bootstrap intervals quantify spatial variation among the
25 sampled windows at each scale, not uncertainty about the computed integers. Two global designs are
reported:

1. fixed-grid bootstrap: all 46 scales remain fixed and windows are resampled within each scale;
2. hierarchical bootstrap: scales are resampled and then windows are resampled within scales, giving a
   broader scale-generalization interval.

## Count models

The primary model is a Poisson log-link count model with the unrestricted-shuffle expectation as an
offset:

    log E[R_w] = log(E_w) + alpha + beta / power.

This directly models the multiplicative real-to-shuffle count ratio. Standard errors are two-way
clustered by scale and repeated window position. GEE fits with independence, exchangeable, and AR(1)
working correlations are sensitivity analyses. A negative-binomial model checks extra-Poisson
variation.

## Scale synthesis

A random-effects meta-analysis treats the 46 scale-level log ratios as scale-balanced effects, using
within-scale bootstrap standard errors. A REML meta-regression on inverse power measures how much
heterogeneity remains after the scale trend is modeled.

## Composition decomposition

The Kitagawa decomposition separates the change in the total real/shuffle ratio between powers 10 and
100 into:

- composition: changes in the expected-count weights of gap groups;
- within-group: changes in the real/shuffle ratio inside each group.

When a group has zero expected mass at one endpoint, its ratio is undefined; the other endpoint ratio is
used so its appearance or disappearance is assigned to composition.

## Modulo 3

Modulo 3 is an explanatory layer, not a correction to the primary statistic. Gaps 2,4,8,10 are exactly
identified forbidden gaps in the available exports. Their expected repeats form a rigorous lower bound
on the structural modulo-3 contribution. The exports do not isolate every possible forbidden gap, so
no complete modulo-3 decomposition is claimed.

## Limits

- The unrestricted shuffle is intentionally not a prime-admissible null; it measures total ordering
  departure, including congruence constraints.
- Candidate asymptotic levels are extrapolations from powers 10 through 100, not proofs of limits.
- Formal p-values are secondary because every window is far below expectation and the main issue is
  effect magnitude and structure.
- The analysis trusts the supplied data and does not rerun prime generation.
"""
(OUT / "07_report/METHODOLOGY_AND_LIMITATIONS.md").write_text(methodology, encoding="utf-8")

# Full report with key tables.
top_groups = gg_pool.sort_values("share_total_missing_count", ascending=False).head(10)
top_special = sg_pool.sort_values("missing_count", ascending=False)
selected_scale_table = scale.loc[scale.power.isin([10, 20, 40, 60, 80, 100]), [
    "power", "real_count", "shuffle_expected_count", "missing_repeat_count",
    "missing_per_100k_pairs", "suppression_total",
]]

full_report = f"""# Full statistical study — Total adjacent-repeat counts

## 1. Study orientation

This analysis treats the **total observed count** as the phenomenon. No gaps are removed from the main
comparison. Modulo 3 is used afterward to explain part of the deficit.

The dataset contains **{len(win):,} nonoverlapping windows**, with **25 windows at each of 46 scales**
from \(10^{{10}}\) through \(10^{{100}}\).

## 2. Headline count result

| Quantity | Value |
|---|---:|
| Real adjacent equal-gap repeats | {pooled_R:,.0f} |
| Unrestricted-shuffle expected repeats | {pooled_E:,.3f} |
| Missing repeats | {pooled_D:,.3f} |
| Real/shuffle count ratio | {pooled_rr:.6f} |
| Total-count suppression | {100*pooled_supp:.3f}% |
| Real repeats per 100,000 adjacent pairs | {100_000*pooled_R/pooled_pairs:.3f} |
| Expected repeats per 100,000 adjacent pairs | {100_000*pooled_E/pooled_pairs:.3f} |
| Missing repeats per 100,000 adjacent pairs | {100_000*pooled_D/pooled_pairs:.3f} |

All **1,150 windows** and all **46 pooled scales** have real counts below their unrestricted-shuffle
expectations. Even the scale-level sign test gives \(p=2^{{-46}}\\approx{2**(-46):.3e}\). This is only a
consistency diagnostic; effect size is more informative.

## 3. Selected scales

{selected_scale_table.to_markdown(index=False, floatfmt=(".0f", ".0f", ".3f", ".3f", ".3f", ".5f"))}

The proportional deficit declines with scale, but the absolute count and the rate per 100,000 pairs
also decline because the fixed-width windows contain fewer primes and a broader gap distribution.

## 4. Bootstrap uncertainty

The fixed-grid 95% interval for suppression is **{100*fixed_supp[1]:.3f}%–{100*fixed_supp[2]:.3f}%**.
The hierarchical interval is **{100*hier_supp[1]:.3f}%–{100*hier_supp[2]:.3f}%**.

The corresponding intervals for missing repeats per 100,000 adjacent pairs are:

- fixed grid: **{fixed_missing_rate[1]:.3f}–{fixed_missing_rate[2]:.3f}**;
- hierarchical: **{hier_missing_rate[1]:.3f}–{hier_missing_rate[2]:.3f}**.

The hierarchical interval is wider because it incorporates variation across the scale trajectory,
whereas the fixed-grid interval conditions on the exact 46 scales studied.

## 5. Scale-balanced synthesis

The count-weighted pooled ratio is **{pooled_rr:.6f}**, but early scales contain many more expected
repeats and therefore dominate that number. A REML random-effects synthesis giving each scale its own
effect estimates a scale-balanced ratio of **{math.exp(mu_re):.6f}**, or
**{100*(1-math.exp(mu_re)):.3f}% suppression**. Its 95% ratio interval is
**{math.exp(mu_re-1.96*se_mu_re):.6f}–{math.exp(mu_re+1.96*se_mu_re):.6f}**.

Heterogeneity is very high before modeling scale, \(I^2={100*I2:.2f}%\), because the ratio changes
systematically across powers. After inverse-power meta-regression, residual \(I^2\) falls to
**{100*I2_resid:.2f}%**.

## 6. Primary count model

The preferred model is

\[
\log \mu_w=\log E_w+\\alpha+\\beta/p.
\]

Two-way clustered estimates are:

- \(\\alpha={float(primary_intercept.estimate):.6f}\) (SE {float(primary_intercept.two_way_cluster_se):.6f});
- \(\\beta={float(primary_slope.estimate):.6f}\) (SE {float(primary_slope.two_way_cluster_se):.6f}).

The negative slope means the real/shuffle ratio is lower at small powers and rises as \(p\) grows. The
candidate asymptotic ratio is **{math.exp(float(primary_intercept.estimate)):.6f}**, or
**{100*(1-math.exp(float(primary_intercept.estimate))):.3f}% suppression**.

The inverse-power model has the best leave-one-power-out Poisson deviance. Adding \(1/p^2\) gives only a
small scale-ratio RMSE improvement while slightly worsening count deviance, so the simpler model is
preferred. The fitted Pearson dispersion is **{primary_fit.pearson_chi2/primary_fit.df_resid:.3f}**,
and NB2 estimates alpha approximately **{float(nb.params[-1]):.3e}**.

The calibration slope of log expected count is very close to one, showing that after scale adjustment,
real repeats are nearly proportional to the shuffle expectation rather than following a different
count scaling law.

## 7. Distribution and window-position stability

Quantile regressions at the 10th, 25th, 50th, 75th, and 90th percentiles all show the same inverse-power
direction. The scale shift therefore occurs throughout the window distribution rather than being driven
by a few extreme windows.

Adding fixed window-position effects increases \(R^2\) by only
**{full_ols.rsquared-base_ols.rsquared:.6f}**. Pooled suppression by window position ranges from
**{100*window_pos.suppression_total.min():.3f}%** to **{100*window_pos.suppression_total.max():.3f}%**.
The repeated offsets around every scale do not materially drive the result.

## 8. Which gap ranges create the deficit?

{top_groups[["gap_group", "real_count", "expected_count", "missing_count", "suppression", "share_total_missing_count"]].to_markdown(index=False, floatfmt=("", ".0f", ".3f", ".3f", ".5f", ".5f"))}

The three largest contributors are the **14–24**, **8–12**, and **26–48** ranges. Together they account
for **{100*top_groups.head(3).share_total_missing_count.sum():.3f}%** of all missing repeats. The deficit
is therefore not concentrated only in gaps 2 and 4.

## 9. Why suppression weakens with scale

From power 10 to power 100, the total real/shuffle ratio rises from **{q10:.6f}** to **{q100:.6f}**, a
change of **{q100-q10:.6f}**.

The Kitagawa decomposition gives:

| Component | Contribution |
|---|---:|
| Composition of expected gap-group counts | {kit_comp_total:.6f} |
| Change within gap groups | {kit_within_total:.6f} |
| Net change | {kit_comp_total+kit_within_total:.6f} |

The composition term is negative: shifts in which broad gap groups carry the shuffle expectation would,
by themselves, slightly **increase** suppression. The positive within-group change more than explains
the observed weakening. This overturns the simple story that the curve falls mainly because gaps
2,4,8,10 become rarer.

## 10. Modulo 3 as an explanatory layer

{top_special[["gap", "mod3_class", "real_count", "expected_count", "missing_count", "suppression", "share_total_missing_count"]].to_markdown(index=False, floatfmt=(".0f", "", ".0f", ".3f", ".3f", ".5f", ".5f"))}

The exactly identified forbidden gaps 2,4,8,10 explain at least
**{100*known_forbidden_total/pooled_D:.3f}%** of the total missing count. This is substantial, but the
admissible gaps 6,12,18,30 still show **{100*(1-adm_real_total/adm_expected_total):.3f}% suppression**.
Thus modulo 3 explains part of the total ordering effect without exhausting it.

## 11. Hardy–Poisson and the count result

Corrected Hardy–Poisson differs from exact shuffle by only
**{100*hp_summary.iloc[0]['mean_absolute_relative_error']:.3f}% mean absolute relative error**, with
correlation **{hp_summary.iloc[0]['pearson_correlation']:.9f}**. Its near-perfect agreement with shuffle
shows that the marginal frequency model is not the problem. The missing ingredient is sequential
ordering.

## 12. Conclusions

1. The total-count phenomenon is large, universal across the sampled windows, and not an artifact of a
   ratio-only presentation.
2. Roughly half of unrestricted-shuffle repeat opportunities are absent in the pooled data.
3. Suppression weakens with scale and is described well by an inverse-power count model, but the fitted
   asymptote is not a proof.
4. Modulo 3 is an important mechanism and provides a rigorous lower-bound decomposition, but broader
   within-range changes dominate the observed scale evolution.
5. Hardy–Poisson reproduces shuffle counts almost exactly, reinforcing the interpretation that the
   main phenomenon lies in order dependence rather than marginal gap frequencies.
"""
(OUT / "07_report/FULL_TOTAL_COUNT_STUDY.md").write_text(full_report, encoding="utf-8")

# Software versions and code.
versions = {
    "python": sys.version, "platform": platform.platform(), "numpy": np.__version__,
    "pandas": pd.__version__, "scipy": scipy.__version__, "statsmodels": statsmodels.__version__,
    "sklearn": sklearn.__version__, "matplotlib": plt.matplotlib.__version__,
    "seed": SEED, "bootstrap_resamples": B,
}
with open(OUT / "08_code/software_versions.json", "w", encoding="utf-8") as f:
    json.dump(versions, f, indent=2)
shutil.copy2(__file__, OUT / "08_code/run_prime_gap_total_count_study.py")

# Data dictionary.
data_dict_rows = [
    ["real_count", "Observed adjacent equal-gap repeat count."],
    ["shuffle_expected_count", "Exact expectation under unrestricted permutation of the same gap multiset."],
    ["missing_repeat_count", "shuffle_expected_count - real_count."],
    ["adjacent_pairs", "Number of adjacent gap pairs available in the window."],
    ["count_ratio_real_to_shuffle", "real_count / shuffle_expected_count."],
    ["suppression_total", "1 - real_count / shuffle_expected_count."],
    ["missing_per_100k_pairs", "100,000 * missing_repeat_count / adjacent_pairs."],
    ["known_forbidden_expected", "Expected repeats from exactly identified forbidden gaps 2,4,8,10."],
    ["share_total_missing_count", "A component's missing count divided by the total missing count."],
    ["composition_component", "Kitagawa contribution caused by changing expected-count weights."],
    ["within_group_component", "Kitagawa contribution caused by changing real/shuffle ratios within groups."],
]
pd.DataFrame(data_dict_rows, columns=["field", "definition"]).to_csv(OUT / "01_analysis_ready/DATA_DICTIONARY.csv", index=False)

# Manifest.
manifest_rows = []
for path in sorted(OUT.rglob("*")):
    if path.is_file():
        manifest_rows.append({
            "relative_path": str(path.relative_to(OUT)), "size_bytes": path.stat().st_size,
            "category": path.parts[len(OUT.parts)] if len(path.parts) > len(OUT.parts) else "root",
        })
pd.DataFrame(manifest_rows).to_csv(OUT / "MANIFEST.csv", index=False)

# README.
readme = """# Prime-gap total-count statistical study v2

This package replaces the earlier correction-first framing. It keeps all gaps in the primary count and
uses modulo 3 only as a secondary explanatory decomposition.

Start with:

- `07_report/EXECUTIVE_SUMMARY.md`
- `07_report/FULL_TOTAL_COUNT_STUDY.md`
- `09_workbook/prime_gap_total_count_analysis.xlsx` (added after the statistical pipeline)

Core outputs:

- `01_analysis_ready/primary_count_window.csv`
- `01_analysis_ready/primary_count_scale.csv`
- `02_inference/scale_BCa_count_intervals_50000.csv`
- `03_count_models/poisson_offset_coefficients_two_way_clustered.csv`
- `03_count_models/count_model_leave_one_power_out_cv.csv`
- `04_composition_and_mod3/kitagawa_decomposition_power10_to_power100.csv`
- `04_composition_and_mod3/mod3_explanatory_global_summary.csv`
- `06_figures/`

No prime generation was rerun. The trusted supplied data were analyzed directly.
"""
(OUT / "README.md").write_text(readme, encoding="utf-8")

print(json.dumps(key, indent=2, default=float))
